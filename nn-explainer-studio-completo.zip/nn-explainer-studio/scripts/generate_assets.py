"""Regenera las 16 máscaras de iconos en assets/masks/ y el catálogo badge_showcase.jpg."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import MASKS_DIR, REF_DIR, render_badge_showcase, save_all_masks


def main() -> None:
    masks = save_all_masks(MASKS_DIR)
    showcase_path = REF_DIR / "badge_showcase.jpg"
    render_badge_showcase(masks, showcase_path)
    print(f"Generadas {len(masks)} máscaras en {MASKS_DIR}")
    print(f"Catálogo visual guardado en {showcase_path}")


if __name__ == "__main__":
    main()
