"""Herramienta reutilizable para extraer fotogramas clave, hojas de contacto y paleta de un vídeo."""

import argparse
import sys
from pathlib import Path
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import DEFAULT_REF_VIDEO


def extract_keyframes(video_path: Path, out_dir: Path, sample_hz: float = 4.0) -> list[Path]:
    """Detecta cambios de escena (histograma HSV + MAD) y guarda fotogramas clave."""
    out_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise FileNotFoundError(f"No se pudo abrir el vídeo: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"Vídeo: {w}x{h} @ {fps:.2f}fps, {total} fotogramas ({total / fps:.2f}s)")

    prev_hist = None
    prev_small = None
    idx = 0
    last_t = -99.0
    step = max(1, int(round(fps / sample_hz)))
    saved: list[Path] = []

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % step == 0:
            t = idx / fps
            small = cv2.resize(frame, (160, 90))
            hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
            hist = cv2.calcHist([hsv], [0, 1], None, [30, 16], [0, 180, 0, 256])
            cv2.normalize(hist, hist)
            diff = 1.0 - cv2.compareHist(prev_hist, hist, cv2.HISTCMP_CORREL) if prev_hist is not None else 1.0
            mad = float(np.mean(np.abs(small.astype(int) - prev_small.astype(int)))) if prev_small is not None else 99.0
            if diff > 0.25 or mad > 25 or (t - last_t) >= 1.5:
                p = out_dir / f"f_{t:06.2f}.jpg"
                cv2.imwrite(str(p), frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
                saved.append(p)
                last_t = t
            prev_hist = hist
            prev_small = small
        idx += 1
    cap.release()
    print(f"{len(saved)} fotogramas clave guardados en {out_dir}")
    return saved


def build_contact_sheets(frames: list[Path], out_dir: Path, thumb_w: int = 580, per_sheet: int = 9) -> None:
    """Agrupa fotogramas en hojas de contacto 3x3 con marca de tiempo."""
    imgs = []
    for f in sorted(frames):
        im = cv2.imread(str(f))
        if im is None:
            continue
        th = int(im.shape[0] * thumb_w / im.shape[1])
        im = cv2.resize(im, (thumb_w, th))
        label = f.stem.replace("f_", "") + "s"
        cv2.putText(im, label, (8, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        imgs.append(im)

    for k in range(0, len(imgs), per_sheet):
        chunk = imgs[k : k + per_sheet]
        while len(chunk) % 3:
            chunk.append(np.full_like(imgs[0], 255))
        rows = [np.hstack(chunk[i : i + 3]) for i in range(0, len(chunk), 3)]
        sheet_path = out_dir / f"sheet_{k // per_sheet}.jpg"
        cv2.imwrite(str(sheet_path), np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 85])


def sample_palette(video_path: Path, timestamp: float, k: int = 6) -> list[str]:
    """Extrae los `k` colores dominantes no blancos en el instante `timestamp`."""
    cap = cv2.VideoCapture(str(video_path))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(timestamp * fps))
    ok, frame = cap.read()
    cap.release()
    if not ok or frame is None:
        return []
    px = frame.reshape(-1, 3)
    sel = px[px.sum(1) < 650]
    if len(sel) < k:
        return []
    _, labels, centers = cv2.kmeans(
        np.float32(sel), k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0), 3, cv2.KMEANS_PP_CENTERS
    )
    counts = np.bincount(labels.ravel())
    return [
        f"#{int(c[2]):02X}{int(c[1]):02X}{int(c[0]):02X}"
        for c, _ in sorted(zip(centers, counts), key=lambda x: -x[1])
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="Analiza un vídeo de referencia (fotogramas, hojas y paleta).")
    parser.add_argument("--video", type=Path, default=DEFAULT_REF_VIDEO, help="Ruta al vídeo a analizar.")
    parser.add_argument("--out", type=Path, default=ROOT / "output" / "analysis", help="Carpeta de salida.")
    parser.add_argument("--palette-at", type=float, default=16.2, help="Segundo para muestrear la paleta.")
    args = parser.parse_args()

    frames = extract_keyframes(args.video, args.out / "frames")
    if frames:
        build_contact_sheets(frames, args.out)
    palette = sample_palette(args.video, args.palette_at)
    if palette:
        print(f"Paleta dominante en t={args.palette_at}s:", ", ".join(palette))


if __name__ == "__main__":
    main()
