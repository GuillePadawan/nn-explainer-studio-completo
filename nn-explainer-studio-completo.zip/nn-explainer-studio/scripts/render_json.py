"""Renderiza un vídeo MP4 directamente desde un archivo JSON de especificación."""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import (
    load_all_masks,
    load_spec_file,
    prepare_nn_logo,
    render_video_from_spec,
    validate_spec,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Genera vídeos MP4 NN × Genesys desde un archivo JSON.")
    parser.add_argument("json_file", type=Path, help="Ruta al archivo .json con la especificación del vídeo.")
    args = parser.parse_args()

    if not args.json_file.exists():
        print(f"Error: no existe el archivo {args.json_file}", file=sys.stderr)
        sys.exit(1)

    spec = load_spec_file(args.json_file)
    errors = validate_spec(spec)
    if errors:
        print("Se encontraron errores en el archivo JSON:", file=sys.stderr)
        for err in errors:
            print(f"  - {err}", file=sys.stderr)
        sys.exit(1)

    masks = load_all_masks()
    logo_bgr, logo_alpha = prepare_nn_logo()
    clean_mp4, sub_mp4 = render_video_from_spec(spec, masks, logo_bgr, logo_alpha)
    print(f"\nVídeo limpio generado en:      {clean_mp4}")
    if sub_mp4:
        print(f"Vídeo subtitulado generado en: {sub_mp4}")


if __name__ == "__main__":
    main()
