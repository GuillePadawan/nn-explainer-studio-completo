@echo off
cd /d "%~dp0"
echo ============================================================
echo   Instalando entorno virtual Python para NN Explainer Studio
echo ============================================================
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo ============================================================
echo   Instalacion completada. Ya puedes abrir iniciar_estudio.bat
echo ============================================================
pause
