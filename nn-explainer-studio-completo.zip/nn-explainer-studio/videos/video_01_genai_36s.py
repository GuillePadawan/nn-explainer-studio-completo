"""Vídeo 01 (36 s): Solución GenAI para análisis de llamadas de clientes."""

import sys
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import (
    COLORS_BGR,
    COLORS_RGB,
    H,
    W,
    clamp,
    draw_badge,
    draw_centered_text,
    draw_falling_digits,
    draw_sound_waves,
    ease_in_out_cubic,
    ease_out_cubic,
    export_videos,
    load_all_masks,
    prepare_nn_logo,
    prog,
    put_nn_logo,
)

DURATION = 36.0

SCRIPT_SEGMENTS = [
    (0.0,  3.4,  "Introducing a new Generative AI-powered solution"),
    (3.4,  6.4,  "...that allows us to analyze thousands of customer calls,"),
    (6.4,  9.1,  "...better understand our customers,"),
    (9.1,  12.0, "...and identify opportunities for improvement."),
    (12.0, 15.1, "For every call, AI analyzes the transcript..."),
    (15.1, 16.7, "...to identify why the customer contacted us,"),
    (16.7, 18.2, "...their intent,"),
    (18.2, 19.7, "...any issues raised,"),
    (19.7, 21.2, "...the outcome of the interaction,"),
    (21.2, 24.8, "...and the evidence behind each insight."),
    (24.8, 28.5, "In this proof of concept..."),
    (28.5, 31.8, "...we analyzed calls handled by one of our external service providers,"),
    (31.8, 36.0, "...giving us greater visibility into why customers contact them and what happens during those conversations."),
]


def render_frame(t: float, masks: dict, logo_bgr: np.ndarray, logo_alpha: np.ndarray) -> np.ndarray:
    canvas = np.full((H, W, 3), 255, dtype=np.uint8)

    # =========================================================================
    # ACTO I: PÁRRAFO 1 (0.0s - 12.0s)
    # =========================================================================
    if t < 12.0:
        if t < 3.4:
            fade_out = 1.0 - ease_in_out_cubic(prog(t, 2.95, 3.40))
            put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=fade_out)
            p_bot = prog(t, 0.15, 0.95)
            draw_badge(canvas, masks, "robot", "green", W // 2, 315, 145, appear_p=p_bot, opacity=fade_out)
            if t > 0.5:
                w_a = fade_out * prog(t, 0.5, 1.0)
                draw_sound_waves(canvas, W // 2 - 40, 315, W // 2 - 420, 315, "green", t, num_arcs=3, span_deg=32, opacity=w_a)
                draw_sound_waves(canvas, W // 2 + 40, 315, W // 2 + 420, 315, "green", t, num_arcs=3, span_deg=32, opacity=w_a)

            pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(pil_img)
            t_txt = ease_out_cubic(prog(t, 0.35, 1.10)) * fade_out
            draw_centered_text(
                draw,
                "Introducing a new\nGenerative AI-powered\nsolution",
                W // 2, 690, "h1", COLORS_RGB["orange"], opacity=t_txt, line_gap=18,
            )
            canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        else:
            pan_out_p = ease_in_out_cubic(prog(t, 11.45, 12.0))
            y_shift = int(round(-pan_out_p * 320))
            fade_end = 1.0 - pan_out_p
            put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=fade_end)

            bg_calls_op = ease_out_cubic(prog(t, 3.7, 4.4)) * (1.0 - ease_in_out_cubic(prog(t, 6.1, 6.7)))
            if bg_calls_op > 0.01:
                mini_coords = [(250, 220), (1670, 220), (250, 770), (1670, 770), (670, 200), (1250, 200)]
                for idx, (mx, my) in enumerate(mini_coords):
                    mp = prog(t, 3.75 + idx * 0.08, 4.35 + idx * 0.08)
                    col_k = "orange" if idx % 2 == 0 else "blue"
                    ic_k = "agent" if idx % 2 == 0 else "customer"
                    draw_badge(canvas, masks, ic_k, col_k, mx, my + y_shift, 68, appear_p=mp, opacity=bg_calls_op * 0.38)

            morph_p = ease_in_out_cubic(prog(t, 6.2, 6.85))
            if morph_p < 0.999:
                op_call_scene = (1.0 - morph_p) * fade_end
                p_ag = prog(t, 3.45, 4.10)
                p_cu = prog(t, 3.65, 4.30)
                p_ai = prog(t, 4.15, 4.85)
                w_op = prog(t, 3.9, 4.4) * op_call_scene
                draw_sound_waves(canvas, 430, 470 + y_shift, 960, 470 + y_shift, "orange", t, num_arcs=3, opacity=w_op)
                draw_sound_waves(canvas, 1490, 470 + y_shift, 960, 470 + y_shift, "blue", t, num_arcs=3, opacity=w_op)
                draw_badge(canvas, masks, "agent", "orange", 430, 470 + y_shift, 175, appear_p=p_ag, opacity=op_call_scene)
                draw_badge(canvas, masks, "customer", "blue", 1490, 470 + y_shift, 175, appear_p=p_cu, opacity=op_call_scene)
                draw_badge(
                    canvas, masks, "robot", "green", 960, 470 + y_shift, 185,
                    appear_p=p_ai, opacity=op_call_scene, highlight_pulse=prog(t, 4.5, 5.8),
                )

            if morph_p > 0.001:
                op_pillars = morph_p * fade_end
                x1 = int(round(430 * (1.0 - morph_p) + 380 * morph_p))
                draw_badge(canvas, masks, "agent", "orange", x1, 455 + y_shift, 168, appear_p=1.0, opacity=op_pillars)

                p_und = prog(t, 6.40, 7.15)
                if p_und > 0.2:
                    draw_sound_waves(canvas, 560, 455 + y_shift, 780, 455 + y_shift, "blue", t, num_arcs=2, span_deg=24, opacity=op_pillars * p_und)
                draw_badge(
                    canvas, masks, "understanding", "blue", 960, 455 + y_shift, 178,
                    appear_p=p_und, opacity=op_pillars, highlight_pulse=prog(t, 6.8, 8.2),
                )

                p_imp = prog(t, 9.10, 9.85)
                if p_imp > 0.2:
                    draw_sound_waves(canvas, 1140, 455 + y_shift, 1360, 455 + y_shift, "red", t, num_arcs=2, span_deg=24, opacity=op_pillars * p_imp)
                draw_badge(
                    canvas, masks, "improvement", "red", 1540, 455 + y_shift, 178,
                    appear_p=p_imp, opacity=op_pillars, highlight_pulse=prog(t, 9.5, 10.9),
                )

            pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(pil_img)
            if morph_p < 0.999:
                lbl1_op = prog(t, 4.1, 4.6) * (1.0 - morph_p) * fade_end
                draw_centered_text(draw, "Analyze thousands of customer calls", W // 2, 775 + y_shift, "h3", COLORS_RGB["orange"], opacity=lbl1_op)
            if morph_p > 0.001:
                op_p = morph_p * fade_end
                draw_centered_text(draw, "Analyze Thousands\nof Customer Calls", 380, 725 + y_shift, "label_b", COLORS_RGB["orange"], opacity=op_p, line_gap=8)
                draw_centered_text(draw, "Better Understand\nOur Customers", 960, 725 + y_shift, "label_b", COLORS_RGB["blue"], opacity=prog(t, 6.55, 7.15) * op_p, line_gap=8)
                draw_centered_text(draw, "Identify Opportunities\nfor Improvement", 1540, 725 + y_shift, "label_b", COLORS_RGB["red"], opacity=prog(t, 9.25, 9.85) * op_p, line_gap=8)
            canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    # =========================================================================
    # ACTO II: PÁRRAFO 2 (12.0s - 25.0s)
    # =========================================================================
    elif t < 25.0:
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)
        cam_pan = ease_in_out_cubic(prog(t, 14.4, 15.4))
        cam_y = int(round(-cam_pan * 420))
        y_top_row = 265 + cam_y
        y_funnel = 640 + cam_y

        pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        digits_op = prog(t, 12.6, 13.2) * (1.0 - prog(t, 15.8, 16.6))
        draw_falling_digits(draw, W // 2, max(0, y_top_row + 130), min(H, y_funnel + 15), t, opacity=digits_op)
        canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        top_row_op = 1.0 - ease_in_out_cubic(prog(t, 14.8, 15.35))
        if top_row_op > 0.01:
            p_in = prog(t, 12.0, 12.65)
            w_op = prog(t, 12.3, 12.8) * (1.0 - cam_pan)
            draw_sound_waves(canvas, 450, y_top_row, 960, y_top_row, "orange", t, num_arcs=3, opacity=w_op)
            draw_sound_waves(canvas, 1470, y_top_row, 960, y_top_row, "blue", t, num_arcs=3, opacity=w_op)
            draw_badge(canvas, masks, "agent", "orange", 450, y_top_row, 148, appear_p=p_in, opacity=top_row_op)
            draw_badge(canvas, masks, "customer", "blue", 1470, y_top_row, 148, appear_p=p_in, opacity=top_row_op)
            draw_badge(canvas, masks, "robot", "green", 960, y_top_row, 158, appear_p=p_in, opacity=top_row_op)

        p_tr = prog(t, 12.55, 13.25)
        funnel_morph = ease_in_out_cubic(prog(t, 14.5, 15.1))
        r_mid = int(round(148 * (1.0 - 0.15 * cam_pan)))
        if funnel_morph < 0.999:
            draw_badge(canvas, masks, "transcript", "green", 960, y_funnel, r_mid, appear_p=p_tr, opacity=1.0 - funnel_morph)
        if funnel_morph > 0.001:
            draw_badge(canvas, masks, "funnel", "lavender", 960, y_funnel, r_mid, appear_p=1.0, opacity=funnel_morph)

        insights = [
            (15.15, "reason",   "blue",     210,  "Why They Contacted Us", "Contact reason"),
            (16.70, "intent",   "orange",   585,  "Customer Intent",       "Goal & purpose"),
            (18.20, "issues",   "red",      960,  "Issues Raised",         "Friction points"),
            (19.70, "outcome",  "green",    1335, "Call Outcome",          "Resolution"),
            (21.20, "evidence", "lavender", 1710, "Insight Evidence",      "Verified proof"),
        ]
        y_row5 = 625
        r_item = 128

        for t_start, ic_name, col_k, target_x, title_l, sub_l in insights:
            if t >= t_start:
                p_item = prog(t, t_start, t_start + 0.70)
                fan_e = ease_out_cubic(p_item)
                cur_x = int(round(960 + (target_x - 960) * fan_e))
                cur_y = int(round((y_funnel + 150) + (y_row5 - (y_funnel + 150)) * fan_e))
                line_op = clamp((p_item - 0.2) / 0.5) * 0.45
                if line_op > 0.02:
                    overlay = canvas.copy()
                    cv2.line(overlay, (960, y_funnel + r_mid + 6), (cur_x, cur_y - r_item - 6), COLORS_BGR[col_k], 3, cv2.LINE_AA)
                    cv2.addWeighted(overlay, line_op, canvas, 1.0 - line_op, 0, dst=canvas)

        for t_start, ic_name, col_k, target_x, title_l, sub_l in insights:
            if t >= t_start:
                p_item = prog(t, t_start, t_start + 0.70)
                fan_e = ease_out_cubic(p_item)
                cur_x = int(round(960 + (target_x - 960) * fan_e))
                cur_y = int(round((y_funnel + 150) + (y_row5 - (y_funnel + 150)) * fan_e))
                draw_badge(
                    canvas, masks, ic_name, col_k, cur_x, cur_y, r_item,
                    appear_p=p_item, opacity=1.0, highlight_pulse=prog(t, t_start + 0.2, t_start + 1.35),
                )

        pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        if cam_pan < 0.99:
            op_2a = prog(t, 12.2, 12.8) * (1.0 - cam_pan)
            draw_centered_text(draw, "For every call, AI analyzes the transcript", W // 2, 875 + cam_y, "h3", COLORS_RGB["slate"], opacity=op_2a)
        for idx, (t_start, ic_name, col_k, target_x, title_l, sub_l) in enumerate(insights):
            if t >= t_start + 0.25:
                txt_op = prog(t, t_start + 0.25, t_start + 0.75)
                draw_centered_text(draw, f"{idx + 1}. {title_l}", target_x, y_row5 + r_item + 42, "label_sm_b", COLORS_RGB[col_k], opacity=txt_op)
                draw_centered_text(draw, sub_l, target_x, y_row5 + r_item + 78, "label_sm_r", COLORS_RGB["slate"], opacity=txt_op * 0.85)
        canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        if t >= 24.05:
            wipe_p = ease_in_out_cubic(prog(t, 24.05, 24.95))
            w_cy = int(round(H + 260 - wipe_p * 720))
            w_r = int(round(180 + wipe_p * 1450))
            cv2.circle(canvas, (W // 2, w_cy), w_r, COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)

    # =========================================================================
    # ACTO III: PÁRRAFO 3 (25.0s - 36.0s)
    # =========================================================================
    else:
        if t >= 27.85:
            put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)
            vis_shift = ease_in_out_cubic(prog(t, 31.6, 32.4))
            x_prov = int(round(450 * (1.0 - vis_shift) + 300 * vis_shift))
            x_cust = int(round(1470 * (1.0 - vis_shift) + 1620 * vis_shift))
            y_main = int(round(520 * (1.0 - vis_shift) + 465 * vis_shift))
            r_side = int(round(168 * (1.0 - vis_shift) + 142 * vis_shift))

            p_prov = prog(t, 28.55, 29.25)
            p_cust = prog(t, 28.75, 29.45)
            p_top_ai = prog(t, 29.15, 29.85)

            if t < 32.3:
                w_op = prog(t, 29.0, 29.5) * (1.0 - vis_shift)
                draw_sound_waves(canvas, x_prov, y_main, 960, y_main, "orange", t, num_arcs=3, opacity=w_op)
                draw_sound_waves(canvas, x_cust, y_main, 960, y_main, "blue", t, num_arcs=3, opacity=w_op)

            draw_badge(
                canvas, masks, "provider", "orange", x_prov, y_main, r_side,
                appear_p=p_prov, opacity=1.0, highlight_pulse=prog(t, 29.3, 30.8),
            )
            draw_badge(canvas, masks, "customer", "blue", x_cust, y_main, r_side, appear_p=p_cust, opacity=1.0)

            if vis_shift < 0.999:
                draw_badge(canvas, masks, "robot", "green", 960, 520, 158, appear_p=p_top_ai, opacity=1.0 - vis_shift)

            if vis_shift > 0.001:
                beam_op = prog(t, 32.1, 32.8) * 0.45
                if beam_op > 0.01:
                    overlay = canvas.copy()
                    cv2.line(overlay, (960, 365), (730, 470), COLORS_BGR["lavender"], 4, cv2.LINE_AA)
                    cv2.line(overlay, (960, 365), (1190, 470), COLORS_BGR["lavender"], 4, cv2.LINE_AA)
                    cv2.line(overlay, (300 + r_side + 8, 465), (730 - 135, 585), COLORS_BGR["orange"], 3, cv2.LINE_AA)
                    cv2.line(overlay, (1620 - r_side - 8, 465), (1190 + 135, 585), COLORS_BGR["blue"], 3, cv2.LINE_AA)
                    cv2.addWeighted(overlay, beam_op, canvas, 1.0 - beam_op, 0, dst=canvas)

                draw_badge(
                    canvas, masks, "visibility", "lavender", 960, 250, 130,
                    appear_p=prog(t, 31.70, 32.45), opacity=vis_shift, highlight_pulse=prog(t, 32.0, 33.2),
                )
                draw_badge(
                    canvas, masks, "reason", "blue", 730, 600, 135,
                    appear_p=prog(t, 32.20, 32.95), opacity=vis_shift, highlight_pulse=prog(t, 32.5, 33.7),
                )
                draw_badge(
                    canvas, masks, "outcome", "green", 1190, 600, 135,
                    appear_p=prog(t, 33.25, 34.00), opacity=vis_shift, highlight_pulse=prog(t, 33.5, 34.8),
                )

            pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(pil_img)
            lbl_prov_op = prog(t, 28.9, 29.5)
            draw_centered_text(draw, "External Service\nProvider", x_prov, y_main + r_side + 52, "label_b", COLORS_RGB["orange"], opacity=lbl_prov_op, line_gap=6)
            draw_centered_text(draw, "Customers", x_cust, y_main + r_side + 36, "label_b", COLORS_RGB["blue"], opacity=lbl_prov_op)

            if vis_shift < 0.999:
                op_3b1 = prog(t, 29.3, 29.9) * (1.0 - vis_shift)
                draw_centered_text(draw, "Analyzing calls handled by our external service provider", W // 2, 825, "h3", COLORS_RGB["slate"], opacity=op_3b1)

            if vis_shift > 0.001:
                draw_centered_text(draw, "Greater Visibility", 960, 62, "h3", COLORS_RGB["lavender"], opacity=vis_shift)
                draw_centered_text(draw, "Why Customers\nContact Them", 730, 785, "label_b", COLORS_RGB["blue"], opacity=prog(t, 32.4, 33.0) * vis_shift, line_gap=6)
                draw_centered_text(draw, "What Happens in\nConversations", 1190, 785, "label_b", COLORS_RGB["green"], opacity=prog(t, 33.4, 34.0) * vis_shift, line_gap=6)

            canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        if t < 28.65:
            orange_layer = np.full((H, W, 3), COLORS_BGR["orange"], dtype=np.uint8)
            p_wave = prog(t, 25.15, 25.95)
            fade_card = 1.0 - ease_in_out_cubic(prog(t, 27.65, 28.05))
            draw_badge(
                orange_layer, masks, "waveform", "white",
                W // 2, 415, 195, appear_p=p_wave, opacity=fade_card, bg_fill_bgr=COLORS_BGR["orange"],
            )
            pil_or = Image.fromarray(cv2.cvtColor(orange_layer, cv2.COLOR_BGR2RGB))
            draw_or = ImageDraw.Draw(pil_or)
            txt_op = prog(t, 25.40, 26.10) * fade_card
            draw_centered_text(draw_or, "Proof of Concept", W // 2, 705, "h1", COLORS_RGB["white"], opacity=txt_op, bg_rgb=COLORS_RGB["orange"])
            draw_centered_text(draw_or, "External Service Provider Call Analysis", W // 2, 790, "h3", COLORS_RGB["white"], opacity=txt_op * 0.92, bg_rgb=COLORS_RGB["orange"])
            orange_layer = cv2.cvtColor(np.array(pil_or), cv2.COLOR_RGB2BGR)

            if t < 27.85:
                canvas = orange_layer
            else:
                rev_p = ease_in_out_cubic(prog(t, 27.85, 28.65))
                mask_c = np.zeros((H, W), dtype=np.uint8)
                w_cy = int(round(360 - rev_p * 780))
                w_r = int(round(1450 * (1.0 - rev_p * 0.72)))
                if w_r > 10:
                    cv2.circle(mask_c, (W // 2, w_cy), w_r, 255, -1, lineType=cv2.LINE_AA)
                m_a = (mask_c.astype(np.float32) / 255.0)[..., None]
                canvas = (canvas.astype(np.float32) * (1.0 - m_a) + orange_layer.astype(np.float32) * m_a).astype(np.uint8)

    return canvas


def main() -> None:
    masks = load_all_masks()
    logo_bgr, logo_alpha = prepare_nn_logo()
    export_videos(
        output_stem="video_nn_genai_36s",
        duration=DURATION,
        render_fn=render_frame,
        masks=masks,
        logo_bgr=logo_bgr,
        logo_alpha=logo_alpha,
        script_segments=SCRIPT_SEGMENTS,
        sample_times=[1.5, 4.8, 7.8, 10.5, 13.5, 16.0, 18.8, 22.5, 24.5, 26.8, 30.2, 34.5],
        preview_prefix="preview36",
    )


if __name__ == "__main__":
    main()
