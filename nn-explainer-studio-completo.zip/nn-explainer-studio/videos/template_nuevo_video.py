"""Plantilla base reutilizable para crear un nuevo vídeo con estilo NN x Genesys.

Copia este archivo (por ejemplo a `videos/video_03_mi_tema.py`), ajusta:
  1. `OUTPUT_STEM` y `DURATION`
  2. `SCRIPT_SEGMENTS` (para la versión de control subtitulada)
  3. `render_frame(t, masks, logo_bgr, logo_alpha)`

Iconos disponibles en `masks`:
  agent, customer, robot, funnel, folder, waveform, transcript, reason,
  intent, issues, outcome, evidence, improvement, understanding, provider, visibility
Colores disponibles:
  "orange", "blue", "green", "lavender", "red", "slate", "white"
"""

import sys
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import (
    COLORS_BGR,
    COLORS_RGB,
    H,
    W,
    draw_badge,
    draw_centered_text,
    draw_sound_waves,
    ease_in_out_cubic,
    export_videos,
    load_all_masks,
    prepare_nn_logo,
    prog,
    put_nn_logo,
)

OUTPUT_STEM = "video_nn_plantilla_10s"
DURATION = 10.0

SCRIPT_SEGMENTS = [
    (0.0, 5.0, "First part of the script synchronized with scene 1."),
    (5.0, 10.0, "Second part of the script synchronized with scene 2."),
]


def render_frame(t: float, masks: dict, logo_bgr: np.ndarray, logo_alpha: np.ndarray) -> np.ndarray:
    canvas = np.full((H, W, 3), 255, dtype=np.uint8)

    if t < 5.0:
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)
        draw_sound_waves(canvas, 500, 480, 1420, 480, "orange", t, num_arcs=3, opacity=prog(t, 0.5, 1.0))
        draw_badge(canvas, masks, "agent", "orange", 500, 480, 175, appear_p=prog(t, 0.1, 0.8))
        draw_badge(canvas, masks, "customer", "blue", 1420, 480, 175, appear_p=prog(t, 0.3, 1.0))

        pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        draw_centered_text(draw, "Scene 1 headline", W // 2, 800, "h2", COLORS_RGB["orange"], opacity=prog(t, 0.4, 1.0))
        canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        if t >= 4.4:
            wipe_p = ease_in_out_cubic(prog(t, 4.4, 5.0))
            cv2.circle(canvas, (W // 2, int(H + 260 - wipe_p * 720)), int(180 + wipe_p * 1450), COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)
    else:
        orange_bg = np.full((H, W, 3), COLORS_BGR["orange"], dtype=np.uint8)
        draw_badge(orange_bg, masks, "waveform", "white", W // 2, 420, 195, appear_p=prog(t, 5.1, 5.9), bg_fill_bgr=COLORS_BGR["orange"])
        pil_or = Image.fromarray(cv2.cvtColor(orange_bg, cv2.COLOR_BGR2RGB))
        draw_or = ImageDraw.Draw(pil_or)
        draw_centered_text(draw_or, "Key Concept", W // 2, 720, "h1", COLORS_RGB["white"], opacity=prog(t, 5.4, 6.1), bg_rgb=COLORS_RGB["orange"])
        canvas = cv2.cvtColor(np.array(pil_or), cv2.COLOR_RGB2BGR)

    return canvas


def main() -> None:
    masks = load_all_masks()
    logo_bgr, logo_alpha = prepare_nn_logo()
    export_videos(
        output_stem=OUTPUT_STEM,
        duration=DURATION,
        render_fn=render_frame,
        masks=masks,
        logo_bgr=logo_bgr,
        logo_alpha=logo_alpha,
        script_segments=SCRIPT_SEGMENTS,
        sample_times=[2.5, 7.5],
        preview_prefix="preview_tpl",
    )


if __name__ == "__main__":
    main()
