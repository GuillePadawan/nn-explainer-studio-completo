"""Vídeo 02 (16 s): De miles de conversaciones a insights y acción."""

import sys
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import (
    COLORS_BGR,
    COLORS_RGB,
    H,
    W,
    clamp,
    draw_badge,
    draw_centered_text,
    draw_falling_digits,
    draw_sound_waves,
    ease_in_out_cubic,
    ease_out_cubic,
    export_videos,
    load_all_masks,
    prepare_nn_logo,
    prog,
    put_nn_logo,
)

DURATION = 16.0

SCRIPT_SEGMENTS = [
    (0.0,  2.95,  "Ultimately, this solution takes us from thousands of conversations..."),
    (2.95, 5.80,  "...to actionable customer insights."),
    (5.80, 8.80,  "From conversations to insights."),
    (8.80, 12.20, "From insights to a deeper understanding of our customers."),
    (12.20, 16.00, "And from understanding to action."),
]


def render_frame(t: float, masks: dict, logo_bgr: np.ndarray, logo_alpha: np.ndarray) -> np.ndarray:
    canvas = np.full((H, W, 3), 255, dtype=np.uint8)

    # =========================================================================
    # ACTO I: PÁRRAFO 1 (0.0s - 5.85s)
    # =========================================================================
    if t < 5.85:
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)
        cam_pan = ease_in_out_cubic(prog(t, 2.75, 3.45))
        cam_y = int(round(-cam_pan * 420))
        y_top_row = 435 + cam_y
        y_funnel = 655 + cam_y

        bg_calls_op = ease_out_cubic(prog(t, 0.25, 0.85)) * (1.0 - ease_in_out_cubic(prog(t, 2.65, 3.20)))
        if bg_calls_op > 0.01:
            mini_coords = [(240, 210), (1680, 210), (240, 720), (1680, 720), (670, 190), (1250, 190)]
            for idx, (mx, my) in enumerate(mini_coords):
                mp = prog(t, 0.28 + idx * 0.06, 0.80 + idx * 0.06)
                col_k = "orange" if idx % 2 == 0 else "blue"
                ic_k = "agent" if idx % 2 == 0 else "customer"
                draw_badge(canvas, masks, ic_k, col_k, mx, my + cam_y, 66, appear_p=mp, opacity=bg_calls_op * 0.40)

        pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        digits_op = prog(t, 2.05, 2.55) * (1.0 - prog(t, 3.55, 4.05))
        draw_falling_digits(draw, W // 2, max(0, y_top_row + 135), min(H, y_funnel + 15), t, opacity=digits_op)
        canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        top_row_op = 1.0 - ease_in_out_cubic(prog(t, 2.95, 3.42))
        if top_row_op > 0.01:
            w_op = prog(t, 0.40, 0.90) * top_row_op
            draw_sound_waves(canvas, 430, y_top_row, 960, y_top_row, "orange", t, num_arcs=3, opacity=w_op)
            draw_sound_waves(canvas, 1490, y_top_row, 960, y_top_row, "blue", t, num_arcs=3, opacity=w_op)
            draw_badge(canvas, masks, "agent", "orange", 430, y_top_row, 165, appear_p=prog(t, 0.10, 0.70), opacity=top_row_op)
            draw_badge(canvas, masks, "customer", "blue", 1490, y_top_row, 165, appear_p=prog(t, 0.22, 0.82), opacity=top_row_op)
            draw_badge(
                canvas, masks, "robot", "green", 960, y_top_row, 175,
                appear_p=prog(t, 0.45, 1.05), opacity=top_row_op, highlight_pulse=prog(t, 0.85, 2.10),
            )

        r_fun = int(round(145 * (1.0 - 0.12 * cam_pan)))
        if t >= 2.25:
            draw_badge(canvas, masks, "funnel", "lavender", 960, y_funnel, r_fun, appear_p=prog(t, 2.25, 2.85), opacity=1.0)

        insight_cards = [
            (3.10, "evidence",    "lavender", 440,  "Customer Insights",        "Verified findings"),
            (3.32, "intent",      "orange",   960,  "Customer Priorities",      "Needs & intent"),
            (3.54, "improvement", "red",      1480, "Actionable Opportunities", "Targeted impact"),
        ]
        y_cards = 605
        r_card = 148

        for t_s, ic_name, col_k, tx, title_l, sub_l in insight_cards:
            if t >= t_s:
                p_c = prog(t, t_s, t_s + 0.62)
                fe = ease_out_cubic(p_c)
                cx = int(round(960 + (tx - 960) * fe))
                cy = int(round((y_funnel + 150) + (y_cards - (y_funnel + 150)) * fe))
                l_op = clamp((p_c - 0.2) / 0.5) * 0.45
                if l_op > 0.02:
                    overlay = canvas.copy()
                    cv2.line(overlay, (960, y_funnel + r_fun + 6), (cx, cy - r_card - 6), COLORS_BGR[col_k], 3, cv2.LINE_AA)
                    cv2.addWeighted(overlay, l_op, canvas, 1.0 - l_op, 0, dst=canvas)

        for t_s, ic_name, col_k, tx, title_l, sub_l in insight_cards:
            if t >= t_s:
                p_c = prog(t, t_s, t_s + 0.62)
                fe = ease_out_cubic(p_c)
                cx = int(round(960 + (tx - 960) * fe))
                cy = int(round((y_funnel + 150) + (y_cards - (y_funnel + 150)) * fe))
                draw_badge(
                    canvas, masks, ic_name, col_k, cx, cy, r_card,
                    appear_p=p_c, opacity=1.0, highlight_pulse=prog(t, t_s + 0.2, t_s + 1.15),
                )

        pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        if top_row_op > 0.02:
            draw_centered_text(
                draw, "From thousands of customer conversations...",
                W // 2, 745 + cam_y, "h3", COLORS_RGB["orange"], opacity=prog(t, 0.35, 0.90) * top_row_op,
            )
        if cam_pan > 0.15:
            for t_s, ic_name, col_k, tx, title_l, sub_l in insight_cards:
                if t >= t_s + 0.20:
                    top_a = prog(t, t_s + 0.20, t_s + 0.65)
                    draw_centered_text(draw, title_l, tx, y_cards + r_card + 44, "label_b", COLORS_RGB[col_k], opacity=top_a)
                    draw_centered_text(draw, sub_l, tx, y_cards + r_card + 82, "label_r", COLORS_RGB["slate"], opacity=top_a * 0.85)
            draw_centered_text(draw, "...to actionable customer insights", W // 2, 925, "h3", COLORS_RGB["slate"], opacity=prog(t, 3.25, 3.80))
        canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        if t >= 5.25:
            wipe_p = ease_in_out_cubic(prog(t, 5.25, 5.85))
            w_cy = int(round(H + 260 - wipe_p * 720))
            w_r = int(round(180 + wipe_p * 1450))
            cv2.circle(canvas, (W // 2, w_cy), w_r, COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)

    # =========================================================================
    # ACTO II: PÁRRAFO 2 (5.85s - 16.0s)
    # =========================================================================
    else:
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)
        y_chain = 485
        r_node = 144

        nodes = [
            (6.05,  "agent",         "orange",   255,  "1. Conversations",        "Customer calls"),
            (6.95,  "evidence",      "lavender", 725,  "2. Insights",             "Extracted findings"),
            (8.85,  "understanding", "blue",     1195, "3. Deeper Understanding", "Of our customers"),
            (12.25, "improvement",   "red",      1665, "4. Action",               "Measurable impact"),
        ]

        if t >= 6.45:
            draw_sound_waves(canvas, 255 + 65, y_chain, 725 - 55, y_chain, "lavender", t, num_arcs=2, span_deg=24, opacity=prog(t, 6.45, 6.95))
        if t >= 8.80:
            draw_sound_waves(canvas, 725 + 65, y_chain, 1195 - 55, y_chain, "blue", t, num_arcs=2, span_deg=24, opacity=prog(t, 8.80, 9.30))
        if t >= 12.20:
            draw_sound_waves(canvas, 1195 + 65, y_chain, 1665 - 55, y_chain, "red", t, num_arcs=2, span_deg=24, opacity=prog(t, 12.20, 12.70))

        for idx, (t_s, ic_name, col_k, nx, title_l, sub_l) in enumerate(nodes):
            if t >= t_s:
                p_n = prog(t, t_s, t_s + 0.68)
                pulse = prog(t, t_s + 0.15, t_s + 1.35)
                if t >= 14.0 + idx * 0.22:
                    pulse = max(pulse, prog(t, 14.0 + idx * 0.22, 14.8 + idx * 0.22))
                draw_badge(canvas, masks, ic_name, col_k, nx, y_chain, r_node, appear_p=p_n, opacity=1.0, highlight_pulse=pulse)

        pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        for idx, (t_s, ic_name, col_k, nx, title_l, sub_l) in enumerate(nodes):
            if t >= t_s + 0.20:
                t_op = prog(t, t_s + 0.20, t_s + 0.70)
                draw_centered_text(draw, title_l, nx, y_chain + r_node + 46, "label_sm_b", COLORS_RGB[col_k], opacity=t_op)
                draw_centered_text(draw, sub_l, nx, y_chain + r_node + 82, "label_sm_r", COLORS_RGB["slate"], opacity=t_op * 0.85)

        if t < 8.80:
            h_op = prog(t, 6.20, 6.75) * (1.0 - prog(t, 8.45, 8.80))
            draw_centered_text(draw, "From conversations to insights", W // 2, 175, "h2", COLORS_RGB["lavender"], opacity=h_op)
        elif t < 12.20:
            h_op = prog(t, 8.85, 9.35) * (1.0 - prog(t, 11.85, 12.20))
            draw_centered_text(draw, "From insights to a deeper understanding of our customers", W // 2, 175, "h3", COLORS_RGB["blue"], opacity=h_op)
        else:
            h_op = prog(t, 12.25, 12.80)
            draw_centered_text(draw, "And from understanding to action", W // 2, 175, "h2", COLORS_RGB["orange"], opacity=h_op)
        canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        if t < 6.35:
            rev_p = ease_in_out_cubic(prog(t, 5.85, 6.35))
            w_cy = int(round(540 - rev_p * 920))
            w_r = int(round(1500 * (1.0 - rev_p * 0.75)))
            if w_r > 10:
                cv2.circle(canvas, (W // 2, w_cy), w_r, COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)

    return canvas


def main() -> None:
    masks = load_all_masks()
    logo_bgr, logo_alpha = prepare_nn_logo()
    export_videos(
        output_stem="video_nn_insights_16s",
        duration=DURATION,
        render_fn=render_frame,
        masks=masks,
        logo_bgr=logo_bgr,
        logo_alpha=logo_alpha,
        script_segments=SCRIPT_SEGMENTS,
        sample_times=[1.5, 4.5, 5.6, 7.8, 10.5, 14.5],
        preview_prefix="preview16",
    )


if __name__ == "__main__":
    main()
