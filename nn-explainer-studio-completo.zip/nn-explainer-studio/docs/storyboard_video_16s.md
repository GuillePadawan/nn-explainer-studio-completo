# Vídeo de 16 segundos sincronizado con el guion (Estilo NN × Genesys)

Script generador: [video_02_insights_16s.py](../videos/video_02_insights_16s.py)

- **Versión limpia (lista para locución):** [video_nn_insights_16s.mp4](../output/video_nn_insights_16s.mp4)
- **Versión con subtítulos sincronizados del guion:** [video_nn_insights_16s_subtitulado.mp4](../output/video_nn_insights_16s_subtitulado.mp4)

---

## Previsualización de escenas

````carousel
![01.5s — Párrafo 1: De miles de conversaciones de clientes](../output/previews/preview16_01.5s.jpg)
<!-- slide -->
![04.5s — Párrafo 1: A hallazgos accionables (despliegue desde el embudo)](../output/previews/preview16_04.5s.jpg)
<!-- slide -->
![05.6s — Transición: Barrido circular naranja entre el párrafo 1 y el 2](../output/previews/preview16_05.6s.jpg)
<!-- slide -->
![07.8s — Párrafo 2 (Paso 1): "From conversations to insights"](../output/previews/preview16_07.8s.jpg)
<!-- slide -->
![10.5s — Párrafo 2 (Paso 2): "From insights to a deeper understanding of our customers"](../output/previews/preview16_10.5s.jpg)
<!-- slide -->
![14.5s — Párrafo 2 (Paso 3): "And from understanding to action"](../output/previews/preview16_14.5s.jpg)
````

---

## Escaleta cronológica segundo a segundo (0.0 s – 16.0 s)

### Bloque 1 — Párrafo 1 (`0.00 s – 5.85 s`)
| Intervalo | Frase exacta del guion | Animación en pantalla |
|---|---|---|
| `0.00 – 2.95 s` | *"Ultimately, this solution takes us from thousands of conversations..."* | Conversación entre agente (`#DD5B13`) y cliente (`#7DA9D3`) con ondas de sonido bidireccionales, rodeada de 6 nodos de llamadas en segundo plano mientras el bot de IA (`#98BC3D`) procesa en el centro. |
| `2.95 – 5.25 s` | *"...to actionable customer insights."* | Lluvia de dígitos verdes (`#98BC3D`) y paneo vertical de cámara hacia el embudo lavanda (`#9B8AC4`), del que se despliegan en abanico 3 bloques de hallazgos accionables: **Customer Insights** (`#9B8AC4`), **Customer Priorities** (`#DD5B13`) y **Actionable Opportunities** (`#D43316`). |
| `5.25 – 6.35 s` | *(Transición entre el párrafo 1 y el 2)* | Barrido circular naranja gigante que sube desde abajo y se eleva hacia arriba para dar paso limpio al segundo párrafo. |

### Bloque 2 — Párrafo 2 (`5.85 s – 16.00 s`)
Construcción progresiva de la cadena de 4 pasos de izquierda a derecha, sincronizada frase a frase:

| Intervalo | Frase exacta del guion | Animación en pantalla |
|---|---|---|
| `6.05 – 8.80 s` | *"From conversations to insights."* | Aparece a la izquierda **1. Conversations** (`#DD5B13`, icono de agente) y emite ondas concéntricas hacia **2. Insights** (`#9B8AC4`, icono de lupa sobre hallazgos), que se despliega en el segundo puesto con el titular superior en lavanda. |
| `8.80 – 12.20 s` | *"From insights to a deeper understanding of our customers."* | Desde **2. Insights** parten ondas azules hacia **3. Deeper Understanding** (`#7DA9D3`, icono de empatía/comprensión del cliente), que aparece en el tercer puesto mientras el titular superior cambia a azul. |
| `12.20 – 16.00 s` | *"And from understanding to action."* | Desde **3. Deeper Understanding** parten ondas hacia **4. Action** (`#D43316`, icono de barras ascendentes y flecha de impacto), completando la fila de 4 etapas con un pulso secuencial de izquierda a derecha (`14.0 – 15.5 s`) y el titular final en naranja NN. |
