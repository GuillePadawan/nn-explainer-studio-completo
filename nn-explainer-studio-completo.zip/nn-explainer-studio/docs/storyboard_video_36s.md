# Vídeo de 36 segundos sincronizado con el guion (Estilo NN × Genesys)

Script generador: [video_01_genai_36s.py](../videos/video_01_genai_36s.py)

- **Versión limpia (lista para locución):** [video_nn_genai_36s.mp4](../output/video_nn_genai_36s.mp4)
- **Versión con subtítulos sincronizados del guion:** [video_nn_genai_36s_subtitulado.mp4](../output/video_nn_genai_36s_subtitulado.mp4)

---

## Previsualización de escenas

````carousel
![01.5s — Párrafo 1: Presentación de la solución de IA Generativa](../output/previews/preview36_01.5s.jpg)
<!-- slide -->
![04.8s — Párrafo 1: Analizar miles de llamadas de clientes](../output/previews/preview36_04.8s.jpg)
<!-- slide -->
![07.8s — Párrafo 1: Comprender mejor a nuestros clientes](../output/previews/preview36_07.8s.jpg)
<!-- slide -->
![10.5s — Párrafo 1: Identificar oportunidades de mejora](../output/previews/preview36_10.5s.jpg)
<!-- slide -->
![13.5s — Párrafo 2: Para cada llamada, la IA analiza la transcripción](../output/previews/preview36_13.5s.jpg)
<!-- slide -->
![16.0s — Párrafo 2: Despliegue secuencial desde el embudo (1. Motivo de contacto)](../output/previews/preview36_16.0s.jpg)
<!-- slide -->
![18.8s — Párrafo 2: Despliegue secuencial (2. Intención y 3. Problemas planteados)](../output/previews/preview36_18.8s.jpg)
<!-- slide -->
![22.5s — Párrafo 2: Los 5 hallazgos completos (incluyendo 4. Resultado y 5. Evidencia)](../output/previews/preview36_22.5s.jpg)
<!-- slide -->
![24.5s — Transición: Barrido circular naranja ascendente](../output/previews/preview36_24.5s.jpg)
<!-- slide -->
![26.8s — Párrafo 3: Cartela naranja "Proof of Concept"](../output/previews/preview36_26.8s.jpg)
<!-- slide -->
![30.2s — Párrafo 3: Llamadas gestionadas por un proveedor externo](../output/previews/preview36_30.2s.jpg)
<!-- slide -->
![34.5s — Párrafo 3: Mayor visibilidad sobre por qué contactan y qué ocurre en las conversaciones](../output/previews/preview36_34.5s.jpg)
````

---

## Escaleta cronológica segundo a segundo (0.0 s – 36.0 s)

### Bloque 1 — Párrafo 1 (`0.0 s – 12.0 s`)
| Intervalo | Frase exacta del guion | Animación en pantalla |
|---|---|---|
| `0.0 – 3.4 s` | *"Introducing a new Generative AI-powered solution..."* | Cartela de apertura sobre fondo blanco con el logo NN arriba a la izquierda, icono circular del bot de IA (`#98BC3D`) con ondas concéntricas y titular en naranja NN (`#DD5B13`). |
| `3.4 – 6.4 s` | *"...that allows us to analyze thousands of customer calls,"* | Aparecen los círculos de agente (`#DD5B13`) y cliente (`#7DA9D3`) con ondas de voz bidireccionales, rodeados de múltiples nodos de llamadas en segundo plano mientras el bot de IA (`#98BC3D`) analiza el flujo en el centro. |
| `6.4 – 9.1 s` | *"...better understand our customers,"* | Se despliega en el centro el icono circular de comprensión/empatía del cliente (`#7DA9D3`) conectado por ondas desde el primer bloque. |
| `9.1 – 12.0 s` | *"...and identify opportunities for improvement."* | Aparece a la derecha el tercer pilar con el icono circular de barras ascendentes y flecha de mejora (`#D43316`), completando los tres beneficios del primer párrafo. |

### Bloque 2 — Párrafo 2 (`12.0 s – 25.0 s`)
| Intervalo | Frase exacta del guion | Animación en pantalla |
|---|---|---|
| `12.0 – 15.1 s` | *"For every call, AI analyzes the transcript..."* | Conversación superior entre agente y cliente procesada por el bot de IA, del que cae la lluvia vertical de dígitos verdes (`#98BC3D`) hacia el icono de transcripción y el embudo lavanda (`#9B8AC4`). |
| `15.1 – 16.7 s` | *"...to identify why the customer contacted us,"* | Paneo vertical hacia el embudo lavanda (`#9B8AC4`), del que se despliega en abanico el **1.er icono**: motivo de contacto (`#7DA9D3`, bocadillo de consulta `?`). |
| `16.7 – 18.2 s` | *"...their intent,"* | Se despliega el **2.º icono**: intención del cliente (`#DD5B13`, diana con flecha). |
| `18.2 – 19.7 s` | *"...any issues raised,"* | Se despliega el **3.er icono**: problemas detectados (`#D43316`, triángulo de alerta). |
| `19.7 – 21.2 s` | *"...the outcome of the interaction,"* | Se despliega el **4.º icono**: resultado de la llamada (`#98BC3D`, escudo con verificación). |
| `21.2 – 24.1 s` | *"...and the evidence behind each insight."* | Se despliega el **5.º icono**: evidencia en la transcripción (`#9B8AC4`, lupa sobre líneas de texto), quedando los 5 hallazgos alineados en fila horizontal. |
| `24.1 – 25.0 s` | *(Transición entre el párrafo 2 y el 3)* | Barrido circular naranja gigante que sube desde el borde inferior hasta cubrir toda la pantalla. |

### Bloque 3 — Párrafo 3 (`25.0 s – 36.0 s`)
| Intervalo | Frase exacta del guion | Animación en pantalla |
|---|---|---|
| `25.0 – 28.5 s` | *"In this proof of concept..."* | Cartela naranja a pantalla completa (`#DD5B13`) con el icono circular blanco de onda de voz y el titular *"Proof of Concept — External Service Provider Call Analysis"*, seguida del barrido circular inverso hacia arriba. |
| `28.5 – 31.8 s` | *"...we analyzed calls handled by one of our external service providers,"* | Aparece a la izquierda el icono circular del proveedor externo (`#DD5B13`, edificio con auriculares) conversando mediante ondas de sonido con el cliente (`#7DA9D3`) a la derecha, con el bot de IA (`#98BC3D`) analizando en el centro. |
| `31.8 – 36.0 s` | *"...giving us greater visibility into why customers contact them and what happens during those conversations."* | En la parte superior central se abre el icono circular de mayor visibilidad (`#9B8AC4`, ojo analítico), que proyecta dos haces hacia los dos bloques inferiores en el orden del texto: **Why Customers Contact Them** (`#7DA9D3`, izquierda) y **What Happens in Conversations** (`#98BC3D`, derecha). |
