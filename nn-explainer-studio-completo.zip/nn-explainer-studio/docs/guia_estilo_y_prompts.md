# Guía de estilo y prompts: vídeo NN × Genesys "Speech Analytics"

Análisis del vídeo de referencia `assets/reference/original_video.mp4` (39 s, 30 fps, 16:9).

> [!NOTE]
> La marca de agua **clideo.com**, la barra del reproductor y los bordes negros vienen de la grabación de pantalla. **No forman parte del estilo**, así que los prompts los excluyen a propósito.

## 1. Estructura del vídeo original

| Tiempo | Escena | Qué ocurre |
|---|---|---|
| 0–9 s | **Cartela de título** | Fondo blanco. Logo NN arriba a la izquierda, logo Genesys en el centro y el claim en naranja. El texto aparece y desaparece con un fundido. |
| 9–14 s | **Conversación** | Dos iconos de línea dentro de círculos: agente (naranja) y cliente (azul). Entre ellos, ondas de sonido en arco que van de un lado a otro. |
| 14–19 s | **Procesamiento con IA** | Aparece un robot (verde) en medio. Caen columnas de dígitos verdes, estilo "matrix". La cámara baja hasta un embudo (morado). |
| 19–24 s | **Organización** | Del embudo sale una carpeta (rojo anaranjado), que se abre en abanico hasta formar 3 carpetas alineadas. |
| 24–25 s | **Transición** | Un círculo naranja enorme sube desde abajo y tapa toda la pantalla (barrido circular). |
| 26–34 s | **Cartela de concepto** | Fondo naranja liso, icono de onda de voz dentro de un círculo blanco y el texto "Speech Analytics" en blanco. |
| 34–39 s | **Demo del producto** | Barrido circular inverso que deja ver una grabación de la interfaz real de Genesys. |

````carousel
![Título](../assets/reference/ref_01_titulo.jpg)
<!-- slide -->
![Conversación](../assets/reference/ref_02_llamada.jpg)
<!-- slide -->
![IA y datos](../assets/reference/ref_03_bot.jpg)
<!-- slide -->
![Carpetas](../assets/reference/ref_04_carpetas.jpg)
<!-- slide -->
![Barrido circular](../assets/reference/ref_05_transicion.jpg)
<!-- slide -->
![Cartela de concepto](../assets/reference/ref_06_speech.jpg)
````

## 2. ADN visual

### Estilo gráfico
- **Motion graphics corporativo 2D plano.** Iconos de **línea monotrazo** (outline), sin relleno, sin sombras, sin degradados y sin 3D.
- **Cada icono va dentro de un círculo** del mismo color y grosor de trazo que el icono. El círculo mide unos **¼ del ancho** del encuadre (≈40 % del alto).
- **Trazo uniforme**, de grosor medio (≈0,4 % del ancho), con **puntas y esquinas redondeadas**.
- Personajes **muy simplificados**: sin rasgos faciales, solo el contorno de la cabeza, el pelo y los accesorios (cascos, teléfono, pajarita).
- **Composición centrada y simétrica**, con mucho espacio en blanco y entre 1 y 3 elementos por escena, alineados en horizontal o en vertical.

### Paleta (medida en el vídeo)

| Uso | Color | Hex |
|---|---|---|
| Fondo principal | Blanco | `#FFFFFF` (en el vídeo se ve `#FCFCFC`) |
| Marca, agente, cartelas | Naranja NN | `#EA650D` (oficial) / `#DD5B13` (medido) |
| Cliente | Azul cielo apagado | `#7DA9D3` |
| IA y datos | Verde lima | `#98BC3D` |
| Filtro y análisis | Lavanda | ≈ `#9B8AC4` |
| Información y archivo | Rojo anaranjado | `#D43316` |
| Texto secundario | Gris pizarra | `#33383D` |

> [!IMPORTANT]
> **Cada concepto tiene un color fijo.** Esto es lo que da coherencia narrativa al vídeo: cuando un concepto vuelve a salir, debe tener siempre el mismo color.

### Tipografía
- Sans-serif humanista, **bold y redondeada**, del tipo NN Nittí Grotesk (alternativas: *Nunito Bold*, *Ubuntu Bold*, *Gilroy Bold*).
- Va **naranja sobre blanco** o **blanca sobre naranja**, siempre centrada y con frases cortas (2–3 líneas como máximo).

### Animación
- **Aparición por escala:** los círculos crecen desde el centro con un pequeño rebote (*ease-out back*).
- **Trazado progresivo:** el contorno se dibuja solo (*stroke draw-on*).
- **Ondas de sonido:** 3–4 arcos concéntricos que se mueven de un icono al otro y pierden opacidad al alejarse.
- **Lluvia de dígitos:** columnas de números finos en verde que caen desde el icono de IA.
- **Paneo vertical de la cámara:** la cámara baja siguiendo el flujo (de la conversación a la IA, al embudo y a las carpetas), como si fuera un diagrama de proceso.
- **Abanico o despliegue:** un elemento se divide en tres con un giro tipo carta.
- **Barrido circular:** un círculo naranja gigante entra desde abajo como transición entre secciones.
- **Ritmo:** 2–4 s por escena, curvas *ease-in-out* suaves, sin cortes bruscos y sin parpadeos.

---

## 3. Prompt maestro para IMAGEN (fotogramas clave)

Pensado para Imagen 4, Midjourney, Flux, Ideogram o DALL·E. Sustituye lo que va `[ENTRE CORCHETES]`.

```text
Flat 2D corporative motion-graphics keyframe, 16:9, clean minimalist explainer-video style.
Pure white background (#FFFFFF), generous negative space, centered symmetrical composition.
[NUMBER] circular line-icon badges arranged [horizontally in a row / vertically in a flow],
each badge is a thin outlined circle containing a simple monoline outline icon of [ICON SUBJECT(S)].
Uniform medium stroke weight, rounded line caps and joins, no fill, no shading, no gradients,
no 3D, no texture. Icon and its circle share the same single color.
Color coding: [customer service agent = NN orange #EA650D] [customer = soft sky blue #7DA9D3]
[AI / data = lime green #98BC3D] [filter / analytics = lavender #9B8AC4]
[documents / archive = red-orange #D43316].
Faceless minimal characters (only head outline, hair and accessories like headset or phone).
[OPTIONAL CONNECTOR: concentric sound-wave arcs between badges / thin vertical columns of small green digits falling below the AI badge].
Vector illustration look, crisp edges, Genesys / NN Group corporate explainer aesthetic,
calm, modern, friendly, professional.
```

### Variante "cartela de concepto naranja"

```text
Flat 2D corporate motion-graphics title card, 16:9. Solid full-bleed NN orange background (#EA650D).
Centered white monoline icon of [ICON, e.g. a sound waveform] inside a thin white outlined circle,
uniform rounded stroke, no fill. Below it, short bold rounded humanist sans-serif headline in white:
"[TEXTO]". Huge negative space, perfectly centered, vector, no gradients, no shadows, no texture.
```

### Variante "cartela de título blanca"

```text
Flat minimalist corporate title card, 16:9, pure white background. Small orange circular brand logo
top-left. Centered short bold rounded humanist sans-serif headline in NN orange (#EA650D),
3 centered lines: "[CLAIM]". Lots of white space, clean vector look, no decoration.
```

---

## 4. Prompt maestro para VÍDEO

Pensado para Veo 3, Runway Gen-4, Kling, Sora o Luma.

```text
2D flat corporate explainer motion graphics, 16:9, 30fps, smooth ease-in-out animation,
pure white background, minimalist vector style identical to a Genesys / NN Group explainer.
Scene: [DESCRIPCIÓN DE LA ACCIÓN].
Visual rules: monoline outline icons inside thin outlined circles, uniform rounded strokes,
no fills, no shadows, no gradients, no 3D, faceless minimal characters,
strict color coding (agent orange #EA650D, customer sky blue #7DA9D3, AI lime green #98BC3D,
analytics lavender #9B8AC4, documents red-orange #D43316).
Motion vocabulary: badges pop in scaling from center with a slight overshoot, outlines draw on
progressively, concentric sound-wave arcs pulse and travel between badges fading in opacity,
thin columns of small green digits rain downward, the camera pans smoothly downward following
a vertical process flow, elements fan out like cards, transitions use a giant solid orange
circle wiping up from the bottom of frame.
Calm, clean, professional pacing, centered composition, plenty of negative space.
No text unless specified, no logos, no watermark, no UI, no realistic imagery.
```

**Ejemplo ya completado** (para una escena nueva sobre "detección de emociones"):

```text
Scene: a customer-service agent badge (orange) on the left and a customer badge (sky blue) on
the right pop in; sound-wave arcs travel between them; a lavender badge with a simple heart-
and-pulse outline icon appears in the center, scales up, and three small lavender circles with
smiley, neutral and sad face outline icons fan out below it. Then a giant solid orange circle
rises from the bottom and fills the frame.
```

---

## 5. Plantillas de escena reutilizables

| # | Tipo | Cómo rellenar `[DESCRIPCIÓN DE LA ACCIÓN]` |
|---|---|---|
| A | Diálogo | "Two badges [A color] and [B color] pop in left and right; sound-wave arcs travel from A to B, then back from B to A in B's color." |
| B | Procesamiento | "A [color] badge with [icon] drops in between; thin columns of [color] digits rain down from it; camera pans down to reveal a [color] badge with [icon]." |
| C | Resultado ×3 | "A single [color] badge with [icon] splits and fans out into three identical badges aligned horizontally." |
| D | Concepto | "Solid orange full frame; a white outlined circle with a white [icon] scales up from tiny at center; white bold headline '[TEXT]' fades in below." |
| E | Transición | "A giant solid orange (#EA650D) circle rises from the bottom edge and covers the whole frame, then shrinks away upward to reveal [next scene]." |

## 6. Prompt negativo

```text
3D, photorealistic, gradients, drop shadows, glow, texture, grain, filled shapes, thick heavy
outlines, sketchy or hand-drawn lines, detailed faces, eyes, mouths, cluttered composition,
busy background, dark background, neon colors, extra colors outside palette, distorted text,
gibberish letters, fake logos, watermark, clideo, video player UI, black borders, letterboxing,
camera shake, flicker, morphing shapes, inconsistent stroke width.
```

## 7. Recomendaciones de producción

> [!WARNING]
> Los generadores de IA **todavía deforman los logotipos y el texto**. Genera las escenas **sin logos ni texto** y añádelos al montar el vídeo (Premiere, After Effects, CapCut o Canva), usando la tipografía y el color de la sección 2.

> [!TIP]
> - **Coherencia entre escenas:** genera primero un fotograma clave con el prompt de imagen y úsalo como *imagen de referencia o primer fotograma* en el generador de vídeo (image-to-video). Así el color y el grosor de trazo se mantienen iguales.
> - **Biblioteca de iconos y renderizado determinista:** este repositorio (`src/nn_motion/`) automatiza exactamente esa biblioteca en código para renderizar cualquier guion nuevo con trazos 100 % uniformes y sincronización exacta al fotograma.
