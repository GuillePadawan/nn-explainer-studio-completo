"""Motor declarativo JSON: convierte una especificación de escenas en fotogramas y vídeos MP4."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable
import cv2
import numpy as np
from PIL import Image, ImageDraw

from .config import COLORS_BGR, COLORS_RGB, H, OUTPUT_DIR, PREVIEWS_DIR, W
from .engine import (
    add_subtitle_overlay,
    clamp,
    draw_badge,
    draw_centered_text,
    draw_falling_digits,
    draw_sound_waves,
    ease_in_out_cubic,
    ease_out_cubic,
    export_videos,
    prog,
    put_nn_logo,
)

VALID_ICONS = {
    "agent",
    "customer",
    "robot",
    "funnel",
    "folder",
    "waveform",
    "transcript",
    "reason",
    "intent",
    "issues",
    "outcome",
    "evidence",
    "improvement",
    "understanding",
    "provider",
    "visibility",
}

VALID_COLORS = set(COLORS_RGB.keys())

VALID_SCENE_TYPES = {
    "title_card",
    "dialogue",
    "dialogue_to_pillars",
    "funnel_fanout",
    "concept_card",
    "dialogue_to_hub",
    "hub_spokes",
    "sequence_row",
}


def _safe_icon(name: str | None, default: str = "robot") -> str:
    if name and name in VALID_ICONS:
        return name
    return default


def _safe_color(color: str | None, default: str = "orange") -> str:
    if color and color in VALID_COLORS:
        return color
    return default


def _distribute_x(n: int, margin: int = 210) -> list[int]:
    """Calcula coordenadas X simétricas para N elementos en un lienzo de ancho W."""
    if n <= 0:
        return []
    if n == 1:
        return [W // 2]
    if n == 2:
        return [620, 1300]
    if n == 3:
        return [440, 960, 1480]
    if n == 4:
        return [255, 725, 1195, 1665]
    if n == 5:
        return [210, 585, 960, 1335, 1710]
    step = (W - 2 * margin) / float(n - 1)
    return [int(round(margin + i * step)) for i in range(n)]


def validate_spec(spec: dict[str, Any]) -> list[str]:
    """Valida una especificación JSON y devuelve una lista de advertencias/errores (vacía si es válida)."""
    errors: list[str] = []
    if not isinstance(spec, dict):
        return ["El documento raíz debe ser un objeto JSON."]
    duration = float(spec.get("duration", 0))
    if duration <= 0 or duration > 600:
        errors.append("El campo 'duration' debe ser un número mayor que 0 y menor o igual a 600 segundos.")
    scenes = spec.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        errors.append("El campo 'scenes' debe ser una lista no vacía de escenas.")
    else:
        for idx, sc in enumerate(scenes):
            stype = sc.get("type", "")
            if stype not in VALID_SCENE_TYPES:
                errors.append(f"Escena #{idx + 1}: tipo '{stype}' no reconocido. Usa uno de: {sorted(VALID_SCENE_TYPES)}.")
            s_start = float(sc.get("start", 0.0))
            s_end = float(sc.get("end", 0.0))
            if s_end <= s_start:
                errors.append(f"Escena #{idx + 1} ({stype}): 'end' ({s_end}) debe ser mayor que 'start' ({s_start}).")
    return errors


def _render_title_card(
    canvas: np.ndarray,
    sc: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
) -> np.ndarray:
    s0 = float(sc.get("start", 0.0))
    s1 = float(sc.get("end", 3.4))
    fade_start = float(sc.get("fade_out_at", max(s0, s1 - 0.45)))
    fade_out = 1.0 - ease_in_out_cubic(prog(t, fade_start, s1))

    if sc.get("show_logo", True):
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=fade_out)

    badge = sc.get("badge") or {}
    icon = _safe_icon(badge.get("icon"), "robot")
    color = _safe_color(badge.get("color"), "green")
    radius = float(badge.get("radius", 145))
    appear_at = float(badge.get("appear_at", s0 + 0.15))
    cy = int(badge.get("cy", 315))
    p_bot = prog(t, appear_at, appear_at + 0.80)
    draw_badge(canvas, masks, icon, color, W // 2, cy, radius, appear_p=p_bot, opacity=fade_out)

    if badge.get("side_waves", True) and t > s0 + 0.5:
        w_a = fade_out * prog(t, s0 + 0.5, s0 + 1.0)
        draw_sound_waves(canvas, W // 2 - 40, cy, W // 2 - 420, cy, color, t, num_arcs=3, span_deg=32, opacity=w_a)
        draw_sound_waves(canvas, W // 2 + 40, cy, W // 2 + 420, cy, color, t, num_arcs=3, span_deg=32, opacity=w_a)

    headline = sc.get("headline") or {}
    if isinstance(headline, str):
        headline = {"text": headline, "color": "orange", "font": "h1"}
    h_text = headline.get("text", "")
    h_col = _safe_color(headline.get("color"), "orange")
    h_font = headline.get("font", "h1")
    h_cy = int(headline.get("cy", 690))

    pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    t_txt = ease_out_cubic(prog(t, s0 + 0.35, s0 + 1.10)) * fade_out
    draw_centered_text(draw, h_text, W // 2, h_cy, h_font, COLORS_RGB[h_col], opacity=t_txt, line_gap=18)

    sub_text = sc.get("subheadline", "")
    if sub_text:
        draw_centered_text(draw, sub_text, W // 2, h_cy + 115, "h3", COLORS_RGB["slate"], opacity=t_txt * 0.9)

    return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)


def _render_dialogue_to_pillars(
    canvas: np.ndarray,
    sc: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
) -> np.ndarray:
    s0 = float(sc.get("start", 3.4))
    s1 = float(sc.get("end", 12.0))
    pillars = sc.get("pillars") or []
    has_pillars = len(pillars) > 0

    exit_pan_at = sc.get("exit_pan_up_at")
    if exit_pan_at is not None:
        pan_out_p = ease_in_out_cubic(prog(t, float(exit_pan_at), s1))
    else:
        pan_out_p = 0.0
    y_shift = int(round(-pan_out_p * 320))
    fade_end = 1.0 - pan_out_p

    if sc.get("show_logo", True):
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=fade_end)

    morph_at = float(sc.get("morph_at", s0 + (s1 - s0) * 0.35)) if has_pillars else (s1 + 10.0)
    morph_p = ease_in_out_cubic(prog(t, morph_at, morph_at + 0.65)) if has_pillars else 0.0

    if sc.get("background_crowd", True):
        bg_calls_op = ease_out_cubic(prog(t, s0 + 0.3, s0 + 1.0)) * (1.0 - ease_in_out_cubic(prog(t, morph_at - 0.1, morph_at + 0.5)))
        if bg_calls_op > 0.01:
            mini_coords = [(250, 220), (1670, 220), (250, 770), (1670, 770), (670, 200), (1250, 200)]
            for idx, (mx, my) in enumerate(mini_coords):
                mp = prog(t, s0 + 0.35 + idx * 0.08, s0 + 0.95 + idx * 0.08)
                col_k = "orange" if idx % 2 == 0 else "blue"
                ic_k = "agent" if idx % 2 == 0 else "customer"
                draw_badge(canvas, masks, ic_k, col_k, mx, my + y_shift, 68, appear_p=mp, opacity=bg_calls_op * 0.38)

    dlg = sc.get("dialogue") or {}
    left_cfg = dlg.get("left") or {"icon": "agent", "color": "orange"}
    right_cfg = dlg.get("right") or {"icon": "customer", "color": "blue"}
    center_cfg = dlg.get("center") or {"icon": "robot", "color": "green"}

    if morph_p < 0.999:
        op_call_scene = (1.0 - morph_p) * fade_end
        t_ag = float(left_cfg.get("appear_at", s0 + 0.05))
        t_cu = float(right_cfg.get("appear_at", s0 + 0.25))
        t_ai = float(center_cfg.get("appear_at", s0 + 0.75))
        p_ag = prog(t, t_ag, t_ag + 0.65)
        p_cu = prog(t, t_cu, t_cu + 0.65)
        p_ai = prog(t, t_ai, t_ai + 0.70)
        w_op = prog(t, s0 + 0.5, s0 + 1.0) * op_call_scene

        l_col = _safe_color(left_cfg.get("color"), "orange")
        r_col = _safe_color(right_cfg.get("color"), "blue")
        c_col = _safe_color(center_cfg.get("color"), "green")

        draw_sound_waves(canvas, 430, 470 + y_shift, 960, 470 + y_shift, l_col, t, num_arcs=3, opacity=w_op)
        draw_sound_waves(canvas, 1490, 470 + y_shift, 960, 470 + y_shift, r_col, t, num_arcs=3, opacity=w_op)
        draw_badge(canvas, masks, _safe_icon(left_cfg.get("icon"), "agent"), l_col, 430, 470 + y_shift, 175, appear_p=p_ag, opacity=op_call_scene)
        draw_badge(canvas, masks, _safe_icon(right_cfg.get("icon"), "customer"), r_col, 1490, 470 + y_shift, 175, appear_p=p_cu, opacity=op_call_scene)
        draw_badge(
            canvas, masks, _safe_icon(center_cfg.get("icon"), "robot"), c_col, 960, 470 + y_shift, 185,
            appear_p=p_ai, opacity=op_call_scene, highlight_pulse=prog(t, t_ai + 0.35, t_ai + 1.65),
        )

    xs_pillars = [380, 960, 1540] if len(pillars) == 3 else _distribute_x(len(pillars), margin=320)
    if morph_p > 0.001 and pillars:
        op_pillars = morph_p * fade_end
        for idx, p_item in enumerate(pillars):
            px = int(p_item.get("x", xs_pillars[idx]))
            p_icon = _safe_icon(p_item.get("icon"), "agent")
            p_col = _safe_color(p_item.get("color"), "orange")
            t_at = float(p_item.get("at", morph_at + idx * 1.5))

            if idx == 0:
                x1 = int(round(430 * (1.0 - morph_p) + px * morph_p))
                draw_badge(canvas, masks, p_icon, p_col, x1, 455 + y_shift, 168, appear_p=1.0, opacity=op_pillars)
            else:
                p_ap = prog(t, t_at, t_at + 0.75)
                prev_x = int(pillars[idx - 1].get("x", xs_pillars[idx - 1]))
                if p_ap > 0.2:
                    draw_sound_waves(
                        canvas, prev_x + 180, 455 + y_shift, px - 180, 455 + y_shift,
                        p_col, t, num_arcs=2, span_deg=24, opacity=op_pillars * p_ap,
                    )
                draw_badge(
                    canvas, masks, p_icon, p_col, px, 455 + y_shift, 178,
                    appear_p=p_ap, opacity=op_pillars, highlight_pulse=prog(t, t_at + 0.4, t_at + 1.8),
                )

    pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    if morph_p < 0.999:
        caption = dlg.get("caption", "")
        cap_col = _safe_color(dlg.get("caption_color"), "orange")
        if caption:
            lbl1_op = prog(t, s0 + 0.7, s0 + 1.2) * (1.0 - morph_p) * fade_end
            draw_centered_text(draw, caption, W // 2, 775 + y_shift, "h3", COLORS_RGB[cap_col], opacity=lbl1_op)
    if morph_p > 0.001 and pillars:
        op_p = morph_p * fade_end
        for idx, p_item in enumerate(pillars):
            px = int(p_item.get("x", xs_pillars[idx]))
            p_col = _safe_color(p_item.get("color"), "orange")
            p_lbl = p_item.get("label", "")
            t_at = float(p_item.get("at", morph_at + idx * 1.5))
            lbl_op = op_p if idx == 0 else (prog(t, t_at + 0.15, t_at + 0.75) * op_p)
            draw_centered_text(draw, p_lbl, px, 725 + y_shift, "label_b", COLORS_RGB[p_col], opacity=lbl_op, line_gap=8)

    return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)


def _render_funnel_fanout(
    canvas: np.ndarray,
    sc: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
) -> np.ndarray:
    s0 = float(sc.get("start", 0.0))
    s1 = float(sc.get("end", 10.0))
    if sc.get("show_logo", True):
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)

    pan_at = float(sc.get("camera_pan_at", s0 + (s1 - s0) * 0.25))
    has_pre = sc.get("pre_funnel_badge") is not None
    pan_dur = 1.0 if has_pre else 0.70
    cam_pan = ease_in_out_cubic(prog(t, pan_at, pan_at + pan_dur))
    cam_y = int(round(-cam_pan * 420))

    y_top_base = 265 if has_pre else 435
    y_fun_base = 640 if has_pre else 655
    y_top_row = y_top_base + cam_y
    y_funnel = y_fun_base + cam_y

    if sc.get("background_crowd", False):
        bg_calls_op = ease_out_cubic(prog(t, s0 + 0.25, s0 + 0.85)) * (1.0 - ease_in_out_cubic(prog(t, pan_at - 0.10, pan_at + 0.45)))
        if bg_calls_op > 0.01:
            mini_coords = [(240, 210), (1680, 210), (240, 720), (1680, 720), (670, 190), (1250, 190)]
            for idx, (mx, my) in enumerate(mini_coords):
                mp = prog(t, s0 + 0.28 + idx * 0.06, s0 + 0.80 + idx * 0.06)
                col_k = "orange" if idx % 2 == 0 else "blue"
                ic_k = "agent" if idx % 2 == 0 else "customer"
                draw_badge(canvas, masks, ic_k, col_k, mx, my + cam_y, 66, appear_p=mp, opacity=bg_calls_op * 0.40)

    pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    dig_start = s0 + 0.60 if has_pre else pan_at - 0.70
    dig_end = pan_at + 1.40 if has_pre else pan_at + 0.80
    digits_op = prog(t, dig_start, dig_start + 0.55) * (1.0 - prog(t, dig_end, dig_end + 0.65))
    draw_falling_digits(draw, W // 2, max(0, y_top_row + 132), min(H, y_funnel + 15), t, opacity=digits_op)
    canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    top_fade_start = pan_at + 0.40 if has_pre else pan_at + 0.20
    top_fade_end = pan_at + 0.95 if has_pre else pan_at + 0.67
    top_row_op = 1.0 - ease_in_out_cubic(prog(t, top_fade_start, top_fade_end))
    top_dlg = sc.get("top_dialogue") or {}
    if top_row_op > 0.01:
        l_cfg = top_dlg.get("left") or {"icon": "agent", "color": "orange"}
        r_cfg = top_dlg.get("right") or {"icon": "customer", "color": "blue"}
        c_cfg = top_dlg.get("center") or {"icon": "robot", "color": "green"}

        if has_pre:
            p_in = prog(t, s0, s0 + 0.65)
            w_op = prog(t, s0 + 0.3, s0 + 0.8) * (1.0 - cam_pan)
            draw_sound_waves(canvas, 450, y_top_row, 960, y_top_row, _safe_color(l_cfg.get("color"), "orange"), t, num_arcs=3, opacity=w_op)
            draw_sound_waves(canvas, 1470, y_top_row, 960, y_top_row, _safe_color(r_cfg.get("color"), "blue"), t, num_arcs=3, opacity=w_op)
            draw_badge(canvas, masks, _safe_icon(l_cfg.get("icon"), "agent"), _safe_color(l_cfg.get("color"), "orange"), 450, y_top_row, 148, appear_p=p_in, opacity=top_row_op)
            draw_badge(canvas, masks, _safe_icon(r_cfg.get("icon"), "customer"), _safe_color(r_cfg.get("color"), "blue"), 1470, y_top_row, 148, appear_p=p_in, opacity=top_row_op)
            draw_badge(canvas, masks, _safe_icon(c_cfg.get("icon"), "robot"), _safe_color(c_cfg.get("color"), "green"), 960, y_top_row, 158, appear_p=p_in, opacity=top_row_op)
        else:
            w_op = prog(t, s0 + 0.40, s0 + 0.90) * top_row_op
            t_l = float(l_cfg.get("appear_at", s0 + 0.10))
            t_r = float(r_cfg.get("appear_at", s0 + 0.22))
            t_c = float(c_cfg.get("appear_at", s0 + 0.45))
            draw_sound_waves(canvas, 430, y_top_row, 960, y_top_row, _safe_color(l_cfg.get("color"), "orange"), t, num_arcs=3, opacity=w_op)
            draw_sound_waves(canvas, 1490, y_top_row, 960, y_top_row, _safe_color(r_cfg.get("color"), "blue"), t, num_arcs=3, opacity=w_op)
            draw_badge(canvas, masks, _safe_icon(l_cfg.get("icon"), "agent"), _safe_color(l_cfg.get("color"), "orange"), 430, y_top_row, 165, appear_p=prog(t, t_l, t_l + 0.60), opacity=top_row_op)
            draw_badge(canvas, masks, _safe_icon(r_cfg.get("icon"), "customer"), _safe_color(r_cfg.get("color"), "blue"), 1490, y_top_row, 165, appear_p=prog(t, t_r, t_r + 0.60), opacity=top_row_op)
            draw_badge(
                canvas, masks, _safe_icon(c_cfg.get("icon"), "robot"), _safe_color(c_cfg.get("color"), "green"), 960, y_top_row, 175,
                appear_p=prog(t, t_c, t_c + 0.60), opacity=top_row_op, highlight_pulse=prog(t, t_c + 0.40, t_c + 1.65),
            )

    fun_cfg = sc.get("funnel_badge") or {"icon": "funnel", "color": "lavender"}
    fun_icon = _safe_icon(fun_cfg.get("icon"), "funnel")
    fun_col = _safe_color(fun_cfg.get("color"), "lavender")

    if has_pre:
        pre_cfg = sc.get("pre_funnel_badge") or {"icon": "transcript", "color": "green"}
        t_pre = float(pre_cfg.get("appear_at", s0 + 0.55))
        p_tr = prog(t, t_pre, t_pre + 0.70)
        morph_t = float(fun_cfg.get("morph_at", pan_at + 0.10))
        funnel_morph = ease_in_out_cubic(prog(t, morph_t, morph_t + 0.60))
        r_mid = int(round(148 * (1.0 - 0.15 * cam_pan)))
        if funnel_morph < 0.999:
            draw_badge(
                canvas, masks, _safe_icon(pre_cfg.get("icon"), "transcript"),
                _safe_color(pre_cfg.get("color"), "green"), 960, y_funnel, r_mid,
                appear_p=p_tr, opacity=1.0 - funnel_morph,
            )
        if funnel_morph > 0.001:
            draw_badge(canvas, masks, fun_icon, fun_col, 960, y_funnel, r_mid, appear_p=1.0, opacity=funnel_morph)
    else:
        r_mid = int(round(145 * (1.0 - 0.12 * cam_pan)))
        t_fun = float(fun_cfg.get("appear_at", pan_at - 0.50))
        if t >= t_fun:
            draw_badge(canvas, masks, fun_icon, fun_col, 960, y_funnel, r_mid, appear_p=prog(t, t_fun, t_fun + 0.60), opacity=1.0)

    items = sc.get("items") or []
    n_items = len(items)
    xs = _distribute_x(n_items)
    y_cards = 625 if n_items >= 4 else 605
    r_card = 128 if n_items >= 4 else 148
    dur_item = 0.70 if n_items >= 4 else 0.62

    for idx, item in enumerate(items):
        t_s = float(item.get("at", pan_at + 0.5 + idx * 1.2))
        if t >= t_s:
            col_k = _safe_color(item.get("color"), "blue")
            tx = int(item.get("x", xs[idx]))
            p_c = prog(t, t_s, t_s + dur_item)
            fe = ease_out_cubic(p_c)
            cx = int(round(960 + (tx - 960) * fe))
            cy = int(round((y_funnel + 150) + (y_cards - (y_funnel + 150)) * fe))
            l_op = clamp((p_c - 0.2) / 0.5) * 0.45
            if l_op > 0.02:
                overlay = canvas.copy()
                cv2.line(overlay, (960, y_funnel + r_mid + 6), (cx, cy - r_card - 6), COLORS_BGR[col_k], 3, cv2.LINE_AA)
                cv2.addWeighted(overlay, l_op, canvas, 1.0 - l_op, 0, dst=canvas)

    for idx, item in enumerate(items):
        t_s = float(item.get("at", pan_at + 0.5 + idx * 1.2))
        if t >= t_s:
            ic_name = _safe_icon(item.get("icon"), "evidence")
            col_k = _safe_color(item.get("color"), "blue")
            tx = int(item.get("x", xs[idx]))
            p_c = prog(t, t_s, t_s + dur_item)
            fe = ease_out_cubic(p_c)
            cx = int(round(960 + (tx - 960) * fe))
            cy = int(round((y_funnel + 150) + (y_cards - (y_funnel + 150)) * fe))
            draw_badge(
                canvas, masks, ic_name, col_k, cx, cy, r_card,
                appear_p=p_c, opacity=1.0, highlight_pulse=prog(t, t_s + 0.2, t_s + 1.25),
            )

    pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)

    top_cap = top_dlg.get("caption", "")
    top_cap_col = _safe_color(top_dlg.get("caption_color"), "slate" if has_pre else "orange")
    if top_cap:
        if has_pre and cam_pan < 0.99:
            op_cap = prog(t, s0 + 0.2, s0 + 0.8) * (1.0 - cam_pan)
            draw_centered_text(draw, top_cap, W // 2, 875 + cam_y, "h3", COLORS_RGB[top_cap_col], opacity=op_cap)
        elif not has_pre and top_row_op > 0.02:
            op_cap = prog(t, s0 + 0.35, s0 + 0.90) * top_row_op
            draw_centered_text(draw, top_cap, W // 2, 745 + cam_y, "h3", COLORS_RGB[top_cap_col], opacity=op_cap)

    numbered = bool(sc.get("numbered_labels", n_items >= 4))
    font_b = "label_sm_b" if n_items >= 4 else "label_b"
    font_r = "label_sm_r" if n_items >= 4 else "label_r"

    for idx, item in enumerate(items):
        t_s = float(item.get("at", pan_at + 0.5 + idx * 1.2))
        if t >= t_s + 0.22:
            col_k = _safe_color(item.get("color"), "blue")
            tx = int(item.get("x", xs[idx]))
            title_l = item.get("label", "")
            if numbered and not title_l.startswith(f"{idx + 1}."):
                title_l = f"{idx + 1}. {title_l}"
            sub_l = item.get("sublabel", "")
            txt_op = prog(t, t_s + 0.22, t_s + 0.70)
            draw_centered_text(draw, title_l, tx, y_cards + r_card + 43, font_b, COLORS_RGB[col_k], opacity=txt_op)
            if sub_l:
                draw_centered_text(draw, sub_l, tx, y_cards + r_card + 80, font_r, COLORS_RGB["slate"], opacity=txt_op * 0.85)

    bot_cap = sc.get("bottom_caption", "")
    if bot_cap and cam_pan > 0.15:
        draw_centered_text(draw, bot_cap, W // 2, 925, "h3", COLORS_RGB["slate"], opacity=prog(t, pan_at + 0.50, pan_at + 1.05))

    canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    wipe_at = sc.get("circle_wipe_out_at")
    if wipe_at is not None and t >= float(wipe_at):
        w0 = float(wipe_at)
        wipe_p = ease_in_out_cubic(prog(t, w0, s1))
        w_cy = int(round(H + 260 - wipe_p * 720))
        w_r = int(round(180 + wipe_p * 1450))
        cv2.circle(canvas, (W // 2, w_cy), w_r, COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)

    return canvas


def _render_concept_card(
    canvas: np.ndarray,
    sc: dict[str, Any],
    t: float,
    masks: dict,
) -> np.ndarray:
    s0 = float(sc.get("start", 25.0))
    s1 = float(sc.get("end", 28.65))
    bg_col = _safe_color(sc.get("bg_color"), "orange")
    rev_at = sc.get("circle_reveal_next_at")
    fade_start = float(rev_at) - 0.20 if rev_at is not None else (s1 - 0.50)

    orange_layer = np.full((H, W, 3), COLORS_BGR[bg_col], dtype=np.uint8)
    badge = sc.get("badge") or {"icon": "waveform", "color": "white"}
    t_ap = float(badge.get("appear_at", s0 + 0.15))
    p_wave = prog(t, t_ap, t_ap + 0.80)
    fade_card = 1.0 - ease_in_out_cubic(prog(t, fade_start, fade_start + 0.40))

    draw_badge(
        orange_layer, masks, _safe_icon(badge.get("icon"), "waveform"),
        _safe_color(badge.get("color"), "white"),
        W // 2, 415, 195, appear_p=p_wave, opacity=fade_card, bg_fill_bgr=COLORS_BGR[bg_col],
    )
    pil_or = Image.fromarray(cv2.cvtColor(orange_layer, cv2.COLOR_BGR2RGB))
    draw_or = ImageDraw.Draw(pil_or)
    txt_op = prog(t, s0 + 0.40, s0 + 1.10) * fade_card
    headline = sc.get("headline", "")
    subheadline = sc.get("subheadline", "")
    if isinstance(headline, dict):
        headline = headline.get("text", "")
    draw_centered_text(draw_or, headline, W // 2, 705, "h1", COLORS_RGB["white"], opacity=txt_op, bg_rgb=COLORS_RGB[bg_col])
    if subheadline:
        draw_centered_text(draw_or, subheadline, W // 2, 790, "h3", COLORS_RGB["white"], opacity=txt_op * 0.92, bg_rgb=COLORS_RGB[bg_col])
    orange_layer = cv2.cvtColor(np.array(pil_or), cv2.COLOR_RGB2BGR)

    if rev_at is None or t < float(rev_at):
        return orange_layer

    rev_p = ease_in_out_cubic(prog(t, float(rev_at), s1))
    mask_c = np.zeros((H, W), dtype=np.uint8)
    w_cy = int(round(360 - rev_p * 780))
    w_r = int(round(1450 * (1.0 - rev_p * 0.72)))
    if w_r > 10:
        cv2.circle(mask_c, (W // 2, w_cy), w_r, 255, -1, lineType=cv2.LINE_AA)
    m_a = (mask_c.astype(np.float32) / 255.0)[..., None]
    return (canvas.astype(np.float32) * (1.0 - m_a) + orange_layer.astype(np.float32) * m_a).astype(np.uint8)


def _render_dialogue_to_hub(
    canvas: np.ndarray,
    sc: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
) -> np.ndarray:
    s0 = float(sc.get("start", 27.85))
    s1 = float(sc.get("end", 36.0))
    if sc.get("show_logo", True):
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)

    shift_at = float(sc.get("hub_shift_at", s0 + (s1 - s0) * 0.45))
    vis_shift = ease_in_out_cubic(prog(t, shift_at, shift_at + 0.80))

    x_prov = int(round(450 * (1.0 - vis_shift) + 300 * vis_shift))
    x_cust = int(round(1470 * (1.0 - vis_shift) + 1620 * vis_shift))
    y_main = int(round(520 * (1.0 - vis_shift) + 465 * vis_shift))
    r_side = int(round(168 * (1.0 - vis_shift) + 142 * vis_shift))

    dlg = sc.get("dialogue") or {}
    l_cfg = dlg.get("left") or {"icon": "provider", "color": "orange", "label": "External Service\nProvider"}
    r_cfg = dlg.get("right") or {"icon": "customer", "color": "blue", "label": "Customers"}
    c_cfg = dlg.get("center") or {"icon": "robot", "color": "green"}

    t_l = float(l_cfg.get("appear_at", s0 + 0.70))
    t_r = float(r_cfg.get("appear_at", s0 + 0.90))
    t_c = float(c_cfg.get("appear_at", s0 + 1.30))

    p_prov = prog(t, t_l, t_l + 0.70)
    p_cust = prog(t, t_r, t_r + 0.70)
    p_top_ai = prog(t, t_c, t_c + 0.70)

    l_col = _safe_color(l_cfg.get("color"), "orange")
    r_col = _safe_color(r_cfg.get("color"), "blue")
    c_col = _safe_color(c_cfg.get("color"), "green")

    if vis_shift < 0.99:
        w_op = prog(t, t_l + 0.45, t_l + 0.95) * (1.0 - vis_shift)
        draw_sound_waves(canvas, x_prov, y_main, 960, y_main, l_col, t, num_arcs=3, opacity=w_op)
        draw_sound_waves(canvas, x_cust, y_main, 960, y_main, r_col, t, num_arcs=3, opacity=w_op)

    draw_badge(
        canvas, masks, _safe_icon(l_cfg.get("icon"), "provider"), l_col, x_prov, y_main, r_side,
        appear_p=p_prov, opacity=1.0, highlight_pulse=prog(t, t_l + 0.75, t_l + 2.25),
    )
    draw_badge(canvas, masks, _safe_icon(r_cfg.get("icon"), "customer"), r_col, x_cust, y_main, r_side, appear_p=p_cust, opacity=1.0)

    if vis_shift < 0.999:
        draw_badge(canvas, masks, _safe_icon(c_cfg.get("icon"), "robot"), c_col, 960, 520, 158, appear_p=p_top_ai, opacity=1.0 - vis_shift)

    hub = sc.get("hub") or {}
    top_b = hub.get("top_badge") or {"icon": "visibility", "color": "lavender", "headline": "Greater Visibility"}
    spokes = hub.get("spokes") or []
    spoke_xs = [730, 1190] if len(spokes) == 2 else _distribute_x(len(spokes), margin=620)

    if vis_shift > 0.001:
        top_col = _safe_color(top_b.get("color"), "lavender")
        t_top = float(top_b.get("at", shift_at + 0.10))
        beam_op = prog(t, shift_at + 0.50, shift_at + 1.20) * 0.45
        if beam_op > 0.01:
            overlay = canvas.copy()
            for idx, sp in enumerate(spokes):
                sx = int(sp.get("x", spoke_xs[idx]))
                cv2.line(overlay, (960, 365), (sx, 470), COLORS_BGR[top_col], 4, cv2.LINE_AA)
            if len(spokes) >= 1:
                s0x = int(spokes[0].get("x", spoke_xs[0]))
                cv2.line(overlay, (300 + r_side + 8, 465), (s0x - 135, 585), COLORS_BGR[l_col], 3, cv2.LINE_AA)
            if len(spokes) >= 2:
                s1x = int(spokes[-1].get("x", spoke_xs[-1]))
                cv2.line(overlay, (1620 - r_side - 8, 465), (s1x + 135, 585), COLORS_BGR[r_col], 3, cv2.LINE_AA)
            cv2.addWeighted(overlay, beam_op, canvas, 1.0 - beam_op, 0, dst=canvas)

        draw_badge(
            canvas, masks, _safe_icon(top_b.get("icon"), "visibility"), top_col, 960, 250, 130,
            appear_p=prog(t, t_top, t_top + 0.75), opacity=vis_shift, highlight_pulse=prog(t, t_top + 0.30, t_top + 1.50),
        )
        for idx, sp in enumerate(spokes):
            sx = int(sp.get("x", spoke_xs[idx]))
            t_sp = float(sp.get("at", shift_at + 0.60 + idx * 1.05))
            sp_col = _safe_color(sp.get("color"), "blue" if idx == 0 else "green")
            draw_badge(
                canvas, masks, _safe_icon(sp.get("icon"), "reason"), sp_col, sx, 600, 135,
                appear_p=prog(t, t_sp, t_sp + 0.75), opacity=vis_shift, highlight_pulse=prog(t, t_sp + 0.30, t_sp + 1.50),
            )

    pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    lbl_prov_op = prog(t, t_l + 0.35, t_l + 0.95)
    if l_cfg.get("label"):
        draw_centered_text(draw, l_cfg["label"], x_prov, y_main + r_side + 52, "label_b", COLORS_RGB[l_col], opacity=lbl_prov_op, line_gap=6)
    if r_cfg.get("label"):
        draw_centered_text(draw, r_cfg["label"], x_cust, y_main + r_side + 36, "label_b", COLORS_RGB[r_col], opacity=lbl_prov_op)

    if vis_shift < 0.999 and dlg.get("caption"):
        op_3b1 = prog(t, t_c + 0.15, t_c + 0.75) * (1.0 - vis_shift)
        draw_centered_text(draw, dlg["caption"], W // 2, 825, "h3", COLORS_RGB["slate"], opacity=op_3b1)

    if vis_shift > 0.001:
        top_col = _safe_color(top_b.get("color"), "lavender")
        if top_b.get("headline"):
            draw_centered_text(draw, top_b["headline"], 960, 62, "h3", COLORS_RGB[top_col], opacity=vis_shift)
        for idx, sp in enumerate(spokes):
            sx = int(sp.get("x", spoke_xs[idx]))
            t_sp = float(sp.get("at", shift_at + 0.60 + idx * 1.05))
            sp_col = _safe_color(sp.get("color"), "blue" if idx == 0 else "green")
            if sp.get("label"):
                draw_centered_text(draw, sp["label"], sx, 785, "label_b", COLORS_RGB[sp_col], opacity=prog(t, t_sp + 0.20, t_sp + 0.80) * vis_shift, line_gap=6)

    return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)


def _render_sequence_row(
    canvas: np.ndarray,
    sc: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
) -> np.ndarray:
    s0 = float(sc.get("start", 0.0))
    s1 = float(sc.get("end", 10.0))
    if sc.get("show_logo", True):
        put_nn_logo(canvas, logo_bgr, logo_alpha, opacity=1.0)

    items = sc.get("items") or []
    n_items = len(items)
    xs = _distribute_x(n_items)
    y_chain = int(sc.get("y", 485))
    r_node = int(sc.get("radius", 144 if n_items == 4 else (128 if n_items >= 5 else 156)))

    for idx in range(1, n_items):
        prev_x = int(items[idx - 1].get("x", xs[idx - 1]))
        cur_x = int(items[idx].get("x", xs[idx]))
        t_item = float(items[idx].get("at", s0 + idx * ((s1 - s0) / max(1, n_items))))
        w_start = t_item - 0.50 if idx == 1 else t_item - 0.05
        col_k = _safe_color(items[idx].get("color"), "blue")
        if t >= w_start:
            draw_sound_waves(
                canvas, prev_x + 65, y_chain, cur_x - 55, y_chain,
                col_k, t, num_arcs=2, span_deg=24, opacity=prog(t, w_start, w_start + 0.50),
            )

    cascade_at = sc.get("final_cascade_pulse_at")
    for idx, item in enumerate(items):
        t_s = float(item.get("at", s0 + idx * ((s1 - s0) / max(1, n_items))))
        if t >= t_s:
            ic_name = _safe_icon(item.get("icon"), "agent")
            col_k = _safe_color(item.get("color"), "orange")
            nx = int(item.get("x", xs[idx]))
            p_n = prog(t, t_s, t_s + 0.68)
            pulse = prog(t, t_s + 0.15, t_s + 1.35)
            if cascade_at is not None and t >= float(cascade_at) + idx * 0.22:
                pulse = max(pulse, prog(t, float(cascade_at) + idx * 0.22, float(cascade_at) + 0.80 + idx * 0.22))
            draw_badge(canvas, masks, ic_name, col_k, nx, y_chain, r_node, appear_p=p_n, opacity=1.0, highlight_pulse=pulse)

    pil_img = Image.fromarray(cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    for idx, item in enumerate(items):
        t_s = float(item.get("at", s0 + idx * ((s1 - s0) / max(1, n_items))))
        if t >= t_s + 0.20:
            col_k = _safe_color(item.get("color"), "orange")
            nx = int(item.get("x", xs[idx]))
            t_op = prog(t, t_s + 0.20, t_s + 0.70)
            title_l = item.get("label", "")
            sub_l = item.get("sublabel", "")
            draw_centered_text(draw, title_l, nx, y_chain + r_node + 46, "label_sm_b", COLORS_RGB[col_k], opacity=t_op)
            if sub_l:
                draw_centered_text(draw, sub_l, nx, y_chain + r_node + 82, "label_sm_r", COLORS_RGB["slate"], opacity=t_op * 0.85)

    headers = sc.get("headers") or []
    if not headers and sc.get("headline"):
        h_obj = sc["headline"]
        if isinstance(h_obj, str):
            headers = [{"start": s0, "end": s1, "text": h_obj, "color": "orange", "font": "h2"}]
        elif isinstance(h_obj, dict):
            headers = [{"start": s0, "end": s1, **h_obj}]

    for h_idx, hdr in enumerate(headers):
        h0 = float(hdr.get("start", s0))
        h1 = float(hdr.get("end", s1))
        if h0 <= t <= h1:
            is_last = h_idx == len(headers) - 1
            fade_in = prog(t, h0 + 0.05, h0 + 0.55)
            fade_out = 1.0 if is_last else (1.0 - prog(t, h1 - 0.35, h1))
            h_col = _safe_color(hdr.get("color"), "orange")
            h_font = hdr.get("font", "h2")
            draw_centered_text(draw, hdr.get("text", ""), W // 2, 175, h_font, COLORS_RGB[h_col], opacity=fade_in * fade_out)
            break

    canvas = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    rev_in_end = sc.get("circle_reveal_in_end")
    if rev_in_end is not None and t < float(rev_in_end):
        rev_p = ease_in_out_cubic(prog(t, s0, float(rev_in_end)))
        w_cy = int(round(540 - rev_p * 920))
        w_r = int(round(1500 * (1.0 - rev_p * 0.75)))
        if w_r > 10:
            cv2.circle(canvas, (W // 2, w_cy), w_r, COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)

    wipe_at = sc.get("circle_wipe_out_at")
    if wipe_at is not None and t >= float(wipe_at):
        w0 = float(wipe_at)
        wipe_p = ease_in_out_cubic(prog(t, w0, s1))
        w_cy = int(round(H + 260 - wipe_p * 720))
        w_r = int(round(180 + wipe_p * 1450))
        cv2.circle(canvas, (W // 2, w_cy), w_r, COLORS_BGR["orange"], -1, lineType=cv2.LINE_AA)

    return canvas


def render_frame_from_spec(
    spec: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
) -> np.ndarray:
    """Renderiza el fotograma en el instante `t` (segundos) a partir de un diccionario JSON `spec`."""
    canvas = np.full((H, W, 3), 255, dtype=np.uint8)
    scenes = spec.get("scenes") or []

    active_normal = []
    active_concept = []
    for sc in scenes:
        s0 = float(sc.get("start", 0.0))
        s1 = float(sc.get("end", 0.0))
        if s0 <= t < s1 or (t == s1 and sc is scenes[-1]):
            if sc.get("type") == "concept_card":
                active_concept.append(sc)
            else:
                active_normal.append(sc)

    for sc in active_normal:
        stype = sc.get("type")
        if stype == "title_card":
            canvas = _render_title_card(canvas, sc, t, masks, logo_bgr, logo_alpha)
        elif stype in ("dialogue_to_pillars", "dialogue"):
            canvas = _render_dialogue_to_pillars(canvas, sc, t, masks, logo_bgr, logo_alpha)
        elif stype == "funnel_fanout":
            canvas = _render_funnel_fanout(canvas, sc, t, masks, logo_bgr, logo_alpha)
        elif stype in ("dialogue_to_hub", "hub_spokes"):
            canvas = _render_dialogue_to_hub(canvas, sc, t, masks, logo_bgr, logo_alpha)
        elif stype == "sequence_row":
            canvas = _render_sequence_row(canvas, sc, t, masks, logo_bgr, logo_alpha)

    for sc in active_concept:
        canvas = _render_concept_card(canvas, sc, t, masks)

    return canvas


def _parse_script_segments(spec: dict[str, Any]) -> list[tuple[float, float, str]]:
    segs = []
    for item in spec.get("script_segments") or []:
        if isinstance(item, dict):
            segs.append((float(item.get("start", 0.0)), float(item.get("end", 0.0)), str(item.get("text", ""))))
        elif isinstance(item, (list, tuple)) and len(item) >= 3:
            segs.append((float(item[0]), float(item[1]), str(item[2])))
    return segs


def render_single_preview_jpeg(
    spec: dict[str, Any],
    t: float,
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
    include_subtitles: bool = True,
) -> bytes:
    """Renderiza un único fotograma en el segundo `t` y devuelve los bytes JPEG."""
    frame = render_frame_from_spec(spec, t, masks, logo_bgr, logo_alpha)
    if include_subtitles and spec.get("subtitles", True):
        segs = _parse_script_segments(spec)
        if segs:
            frame = add_subtitle_overlay(frame, t, segs)
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise RuntimeError("Error al codificar el fotograma en JPEG.")
    return buf.tobytes()


def render_video_from_spec(
    spec: dict[str, Any],
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
    out_dir: Path = OUTPUT_DIR,
    previews_dir: Path = PREVIEWS_DIR,
    progress_callback: Callable[[int, int, float], None] | None = None,
) -> tuple[Path, Path | None]:
    """Renderiza el vídeo MP4 limpio (y subtitulado si procede) desde un diccionario o JSON."""
    output_stem = str(spec.get("output_stem", "video_nn_custom")).strip() or "video_nn_custom"
    duration = float(spec.get("duration", 16.0))
    segs = _parse_script_segments(spec) if spec.get("subtitles", True) else None
    sample_times = [float(x) for x in (spec.get("sample_times") or [])]
    if not sample_times:
        step = max(1.5, round(duration / 6.0, 1))
        sample_times = [round(min(duration - 0.2, (i + 0.5) * step), 1) for i in range(6)]

    def _fn(t: float, m: dict, lb: np.ndarray, la: np.ndarray) -> np.ndarray:
        return render_frame_from_spec(spec, t, m, lb, la)

    return export_videos(
        output_stem=output_stem,
        duration=duration,
        render_fn=_fn,
        masks=masks,
        logo_bgr=logo_bgr,
        logo_alpha=logo_alpha,
        script_segments=segs,
        sample_times=sample_times,
        preview_prefix=f"preview_{output_stem}",
        out_dir=out_dir,
        previews_dir=previews_dir,
        progress_callback=progress_callback,
    )


def load_spec_file(json_path: str | Path) -> dict[str, Any]:
    """Lee un archivo JSON de especificación de vídeo con codificación UTF-8."""
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)
