"""Configuración global, paleta de marca, rutas y tipografía."""

from pathlib import Path
from PIL import ImageFont

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ASSETS_DIR = PROJECT_ROOT / "assets"
LOGOS_DIR = ASSETS_DIR / "logos"
MASKS_DIR = ASSETS_DIR / "masks"
REF_DIR = ASSETS_DIR / "reference"
OUTPUT_DIR = PROJECT_ROOT / "output"
PREVIEWS_DIR = OUTPUT_DIR / "previews"

DEFAULT_TITLE_CARD = LOGOS_DIR / "nn_title_card.png"
DEFAULT_REF_VIDEO = REF_DIR / "original_video.mp4"

# Dimensiones estándar de salida (Full HD 16:9 a 30 fps)
W, H = 1920, 1080
FPS = 30

# Lienzo normalizado de los iconos (doble resolución para anti-aliasing limpio)
BADGE_SZ = 800
BADGE_C = 400
BADGE_R = 356
STROKE = 15

# Paleta corporativa medida sobre el vídeo de referencia
COLORS_RGB = {
    "orange":   (221, 91, 19),    # #DD5B13 Naranja NN (marca / agente / intención)
    "blue":     (125, 169, 211),  # #7DA9D3 Azul cielo (cliente / comprensión)
    "green":    (152, 188, 61),   # #98BC3D Verde lima (IA / datos / resultado)
    "lavender": (155, 138, 196),  # #9B8AC4 Lavanda (filtro / análisis / evidencia)
    "red":      (212, 51, 22),    # #D43316 Rojo anaranjado (archivos / alertas / acción)
    "slate":    (51, 56, 61),     # #33383D Gris pizarra (texto secundario)
    "white":    (255, 255, 255),  # #FFFFFF Blanco puro
}
COLORS_BGR = {k: (v[2], v[1], v[0]) for k, v in COLORS_RGB.items()}

FONT_BOLD_PATH = Path(r"C:\Windows\Fonts\segoeuib.ttf")
FONT_SEMI_PATH = Path(r"C:\Windows\Fonts\segoeuisl.ttf")
FONT_REG_PATH = Path(r"C:\Windows\Fonts\segoeui.ttf")
FONT_MONO_PATH = Path(r"C:\Windows\Fonts\consola.ttf")


def _get_font(path: Path, size: int):
    try:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    except Exception:
        pass
    return ImageFont.load_default()


def load_fonts() -> dict:
    """Carga la jerarquía tipográfica para titulares, etiquetas, subtítulos y dígitos."""
    return {
        "h1": _get_font(FONT_BOLD_PATH, 66),
        "h2": _get_font(FONT_BOLD_PATH, 54),
        "h3": _get_font(FONT_BOLD_PATH, 38),
        "label_b": _get_font(FONT_BOLD_PATH, 28),
        "label_r": _get_font(FONT_REG_PATH, 23),
        "label_sm_b": _get_font(FONT_BOLD_PATH, 25),
        "label_sm_r": _get_font(FONT_REG_PATH, 20),
        "sub": _get_font(FONT_REG_PATH, 26),
        "mono": _get_font(FONT_MONO_PATH, 23),
    }
