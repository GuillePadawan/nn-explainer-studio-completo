"""Biblioteca de máscaras de iconos monotrazo (800x800) y catálogo visual."""

import math
from pathlib import Path
import cv2
import numpy as np

from .config import (
    BADGE_C,
    BADGE_R,
    BADGE_SZ,
    COLORS_BGR,
    DEFAULT_REF_VIDEO,
    MASKS_DIR,
    STROKE,
)

ORIGINAL_ICON_SPECS = {
    "agent":    (11.20, 402.5, 483.0, 205.0, False),
    "customer": (11.20, 1348.0, 483.0, 205.0, False),
    "robot":    (15.05, 879.0, 457.5, 205.0, False),
    "funnel":   (18.20, 879.5, 513.5, 205.0, False),
    "folder":   (22.50, 879.5, 509.0, 205.0, False),
    "waveform": (28.00, 879.5, 381.0, 199.5, True),
}

DEFAULT_BADGE_COLORS = {
    "agent": "orange",
    "customer": "blue",
    "robot": "green",
    "funnel": "lavender",
    "folder": "red",
    "waveform": "orange",
    "transcript": "green",
    "reason": "blue",
    "intent": "orange",
    "issues": "red",
    "outcome": "green",
    "evidence": "lavender",
    "improvement": "red",
    "understanding": "blue",
    "provider": "orange",
    "visibility": "lavender",
}


def extract_original_interior_masks(video_path: Path = DEFAULT_REF_VIDEO) -> dict:
    """Extrae los 6 iconos originales desde el vídeo de referencia."""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise FileNotFoundError(f"No se pudo abrir el vídeo de referencia: {video_path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    masks = {}
    for name, (t, cx, cy, orig_r, on_orange) in ORIGINAL_ICON_SPECS.items():
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(t * fps))
        ok, frame = cap.read()
        if not ok or frame is None:
            raise RuntimeError(f"No se pudo leer el fotograma {t}s para el icono '{name}'")
        scale_r = orig_r * (BADGE_C / BADGE_R)
        M = np.float32([
            [BADGE_C / scale_r, 0, BADGE_C - cx * (BADGE_C / scale_r)],
            [0, BADGE_C / scale_r, BADGE_C - cy * (BADGE_C / scale_r)],
        ])
        patch = cv2.warpAffine(
            frame, M, (BADGE_SZ, BADGE_SZ), flags=cv2.INTER_CUBIC, borderValue=(255, 255, 255)
        )
        if on_orange:
            bg = np.median(patch[:40, :40].reshape(-1, 3), axis=0)
            dist = np.linalg.norm(patch.astype(np.float32) - bg, axis=2)
            raw = np.clip((dist - 35.0) / 85.0, 0.0, 1.0)
        else:
            bg = np.array([252.0, 252.0, 252.0], dtype=np.float32)
            dist = np.linalg.norm(patch.astype(np.float32) - bg, axis=2)
            raw = np.clip((dist - 22.0) / 55.0, 0.0, 1.0)

        yy, xx = np.ogrid[:BADGE_SZ, :BADGE_SZ]
        rr = np.sqrt((xx - BADGE_C) ** 2 + (yy - BADGE_C) ** 2)
        margin = 38.0 if name == "waveform" else 22.0
        interior = np.clip((BADGE_R - margin - rr) / 4.0, 0.0, 1.0)
        mask = raw * interior
        mask_blur = cv2.GaussianBlur(mask, (7, 7), 1.4)
        mask_crisp = np.clip((mask_blur - 0.28) / 0.35, 0.0, 1.0)
        masks[name] = (mask_crisp * 255).astype(np.uint8)
    cap.release()
    return masks


def draw_polyline(mask: np.ndarray, pts: list, closed: bool = False, thickness: int = STROKE) -> None:
    """Dibuja una polilínea en la máscara con remates y uniones redondeadas."""
    pts_arr = np.array(pts, dtype=np.int32).reshape((-1, 1, 2))
    cv2.polylines(mask, [pts_arr], isClosed=closed, color=255, thickness=thickness, lineType=cv2.LINE_AA)
    r = thickness // 2
    for p in pts:
        cv2.circle(mask, (int(p[0]), int(p[1])), r, 255, -1, lineType=cv2.LINE_AA)


def draw_arc_pts(cx: float, cy: float, rx: float, ry: float, a0_deg: float, a1_deg: float, steps: int = 60) -> list:
    """Genera una lista de puntos sobre un arco elíptico entre a0_deg y a1_deg."""
    angles = np.linspace(math.radians(a0_deg), math.radians(a1_deg), steps)
    return [(cx + rx * math.cos(a), cy + ry * math.sin(a)) for a in angles]


def create_custom_interior_masks() -> dict:
    """Genera los 10 iconos procedurales monotrazo con el mismo estilo que los originales."""
    masks = {}

    # 1. "transcript": Documento con esquina doblada y líneas de texto
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    page_pts = [(270, 210), (465, 210), (535, 280), (535, 585), (270, 585)]
    draw_polyline(m, page_pts, closed=True)
    draw_polyline(m, [(465, 210), (465, 280), (535, 280)], closed=False)
    for y, x1 in [(345, 480), (405, 480), (465, 480), (525, 415)]:
        draw_polyline(m, [(320, y), (x1, y)], closed=False)
    masks["transcript"] = m

    # 2. "reason": Bocadillo simétrico con interrogación
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    bub = draw_arc_pts(400, 375, 165, 138, -222, 82, 80)
    bub_tail = [bub[-1], (340, 548), (318, 472), bub[0]]
    draw_polyline(m, bub + bub_tail, closed=True)
    q_arc = draw_arc_pts(400, 330, 40, 36, -185, 45, 35)
    q_stem = [q_arc[-1], (400, 382), (400, 402)]
    draw_polyline(m, q_arc + q_stem, closed=False, thickness=16)
    cv2.circle(m, (400, 440), 11, 255, -1, lineType=cv2.LINE_AA)
    masks["reason"] = m

    # 3. "intent": Diana concéntrica con flecha al centro
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    ring1 = draw_arc_pts(385, 415, 155, 155, -25, 305, 70)
    ring2 = draw_arc_pts(385, 415, 92, 92, -15, 295, 50)
    draw_polyline(m, ring1, closed=False)
    draw_polyline(m, ring2, closed=False)
    cv2.circle(m, (385, 415), 24, 255, -1, lineType=cv2.LINE_AA)
    draw_polyline(m, [(565, 235), (395, 405)], closed=False)
    draw_polyline(m, [(455, 405), (395, 405), (395, 345)], closed=False)
    draw_polyline(m, [(525, 235), (565, 235), (565, 275)], closed=False)
    masks["intent"] = m

    # 4. "issues": Triángulo redondeado de alerta con exclamación
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    tri_pts = (
        draw_arc_pts(400, 255, 28, 28, -150, -30, 20)
        + draw_arc_pts(550, 530, 28, 28, -30, 90, 20)
        + draw_arc_pts(250, 530, 28, 28, 90, 210, 20)
    )
    draw_polyline(m, tri_pts, closed=True)
    draw_polyline(m, [(400, 330), (400, 445)], closed=False, thickness=18)
    cv2.circle(m, (400, 498), 12, 255, -1, lineType=cv2.LINE_AA)
    masks["issues"] = m

    # 5. "outcome": Escudo con marca de verificación
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    shield = (
        [(265, 270), (400, 220), (535, 270), (535, 405)]
        + draw_arc_pts(400, 405, 135, 175, 0, 180, 45)
    )
    draw_polyline(m, shield, closed=True)
    draw_polyline(m, [(330, 395), (382, 448), (478, 342)], closed=False, thickness=18)
    masks["outcome"] = m

    # 6. "evidence": Lupa enfocando líneas de transcripción
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    draw_polyline(m, [(240, 280), (430, 280)], closed=False)
    draw_polyline(m, [(240, 340), (355, 340)], closed=False)
    draw_polyline(m, [(240, 400), (325, 400)], closed=False)
    cv2.circle(m, (430, 415), 105, 255, thickness=STROKE, lineType=cv2.LINE_AA)
    draw_polyline(m, [(375, 415), (485, 415)], closed=False)
    draw_polyline(m, [(395, 455), (465, 455)], closed=False)
    draw_polyline(m, [(505, 490), (585, 570)], closed=False, thickness=22)
    masks["evidence"] = m

    # 7. "improvement": Barras ascendentes con flecha de tendencia
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    draw_polyline(m, [(235, 555), (565, 555)], closed=False)
    for bx, top_y in [(270, 455), (375, 385), (480, 305)]:
        bar = [(bx, 555), (bx, top_y), (bx + 55, top_y), (bx + 55, 555)]
        draw_polyline(m, bar, closed=False)
    draw_polyline(m, [(265, 380), (385, 295), (515, 220)], closed=False)
    draw_polyline(m, [(455, 218), (515, 220), (505, 280)], closed=False)
    masks["improvement"] = m

    # 8. "understanding": Corazón monotrazo con arco superior de empatía
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    left_lobe = draw_arc_pts(332, 345, 72, 72, -195, 0, 35)
    right_lobe = draw_arc_pts(468, 345, 72, 72, -180, 15, 35)
    heart_pts = left_lobe + right_lobe + [(400, 545), left_lobe[0]]
    draw_polyline(m, heart_pts, closed=True)
    arc_top = draw_arc_pts(400, 320, 165, 145, -135, -45, 30)
    draw_polyline(m, arc_top, closed=False)
    masks["understanding"] = m

    # 9. "provider": Edificio corporativo con diadema de servicio
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    arch = draw_arc_pts(400, 390, 155, 155, -180, 0, 50)
    draw_polyline(m, arch, closed=False)
    draw_polyline(m, [(225, 380), (265, 380), (265, 455), (225, 455)], closed=True)
    draw_polyline(m, [(535, 380), (575, 380), (575, 455), (535, 455)], closed=True)
    bldg = [(315, 560), (315, 325), (485, 325), (485, 560)]
    draw_polyline(m, bldg, closed=True)
    for wy in [380, 440]:
        draw_polyline(m, [(355, wy), (380, wy)], closed=False)
        draw_polyline(m, [(420, wy), (445, wy)], closed=False)
    draw_polyline(m, [(375, 560), (375, 495), (425, 495), (425, 560)], closed=False)
    masks["provider"] = m

    # 10. "visibility": Ojo analítico
    m = np.zeros((BADGE_SZ, BADGE_SZ), dtype=np.uint8)
    top_lid = draw_arc_pts(400, 495, 215, 195, -142, -38, 45)
    bot_lid = draw_arc_pts(400, 305, 215, 195, 38, 142, 45)
    draw_polyline(m, top_lid + bot_lid, closed=True)
    cv2.circle(m, (400, 400), 68, 255, thickness=STROKE, lineType=cv2.LINE_AA)
    cv2.circle(m, (400, 400), 22, 255, -1, lineType=cv2.LINE_AA)
    masks["visibility"] = m

    return masks


def save_all_masks(masks_dir: Path = MASKS_DIR, video_path: Path = DEFAULT_REF_VIDEO) -> dict:
    """Genera y guarda todas las máscaras PNG de 800x800 en `masks_dir`."""
    masks_dir.mkdir(parents=True, exist_ok=True)
    orig = extract_original_interior_masks(video_path)
    cust = create_custom_interior_masks()
    all_masks = {**orig, **cust}
    for name, mask in all_masks.items():
        cv2.imwrite(str(masks_dir / f"{name}.png"), mask)
    return all_masks


def load_all_masks(masks_dir: Path = MASKS_DIR, video_path: Path = DEFAULT_REF_VIDEO) -> dict:
    """
    Carga las máscaras cacheadas desde `assets/masks/*.png`.
    Si alguna falta, las regenera automáticamente.
    """
    expected = list(DEFAULT_BADGE_COLORS.keys())
    if all((masks_dir / f"{name}.png").exists() for name in expected):
        masks = {}
        for name in expected:
            m = cv2.imread(str(masks_dir / f"{name}.png"), cv2.IMREAD_GRAYSCALE)
            if m is not None:
                masks[name] = m
        if len(masks) == len(expected):
            return masks

    cust = create_custom_interior_masks()
    if all((masks_dir / f"{name}.png").exists() for name in ORIGINAL_ICON_SPECS):
        orig = {
            name: cv2.imread(str(masks_dir / f"{name}.png"), cv2.IMREAD_GRAYSCALE)
            for name in ORIGINAL_ICON_SPECS
        }
        return {**orig, **cust}

    return save_all_masks(masks_dir, video_path)


def render_badge_showcase(all_masks: dict, out_path: Path) -> None:
    """Genera una hoja de catálogo visual 4x4 con todos los iconos disponibles."""
    cells = []
    for name, mask in all_masks.items():
        canvas = np.full((BADGE_SZ, BADGE_SZ, 3), 255, dtype=np.uint8)
        col = COLORS_BGR[DEFAULT_BADGE_COLORS.get(name, "orange")]
        cv2.circle(canvas, (BADGE_C, BADGE_C), BADGE_R, col, thickness=STROKE, lineType=cv2.LINE_AA)
        alpha = (mask.astype(np.float32) / 255.0)[..., None]
        col_arr = np.array(col, dtype=np.float32)[None, None, :]
        canvas = (canvas.astype(np.float32) * (1.0 - alpha) + col_arr * alpha).astype(np.uint8)
        small = cv2.resize(canvas, (260, 260), interpolation=cv2.INTER_AREA)
        cv2.putText(small, name, (12, 248), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (40, 40, 40), 2, cv2.LINE_AA)
        cells.append(small)

    while len(cells) % 4:
        cells.append(np.full_like(cells[0], 255))
    rows = [np.hstack(cells[i : i + 4]) for i in range(0, len(cells), 4)]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 92])
