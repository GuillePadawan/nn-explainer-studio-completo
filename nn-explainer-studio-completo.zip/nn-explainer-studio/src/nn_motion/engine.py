"""Primitivas de animación 2D, tipografía, subtítulos y exportación MP4 con ffmpeg."""

import math
import subprocess
from pathlib import Path
from typing import Callable
import cv2
import numpy as np
from PIL import Image, ImageDraw
import imageio_ffmpeg

from .config import (
    BADGE_C,
    BADGE_R,
    BADGE_SZ,
    COLORS_BGR,
    COLORS_RGB,
    DEFAULT_TITLE_CARD,
    FPS,
    H,
    OUTPUT_DIR,
    PREVIEWS_DIR,
    STROKE,
    W,
    load_fonts,
)

FONTS = load_fonts()


def clamp(x: float, a: float = 0.0, b: float = 1.0) -> float:
    return max(a, min(b, x))


def prog(t: float, t0: float, t1: float) -> float:
    """Normaliza el tiempo `t` dentro del intervalo [t0, t1] al rango [0.0, 1.0]."""
    if t1 <= t0:
        return 1.0 if t >= t0 else 0.0
    return clamp((t - t0) / (t1 - t0), 0.0, 1.0)


def ease_out_cubic(x: float) -> float:
    x = clamp(x)
    return 1.0 - (1.0 - x) ** 3


def ease_in_out_cubic(x: float) -> float:
    x = clamp(x)
    return 4 * x * x * x if x < 0.5 else 1.0 - ((-2 * x + 2) ** 3) / 2.0


def ease_out_back(x: float, s: float = 1.35) -> float:
    x = clamp(x)
    c1 = s
    c3 = c1 + 1.0
    return 1.0 + c3 * ((x - 1.0) ** 3) + c1 * ((x - 1.0) ** 2)


def prepare_nn_logo(title_card_path: Path = DEFAULT_TITLE_CARD, target_height: int = 108):
    """Recorta y prepara el logotipo corporativo NN desde la imagen de referencia."""
    png = cv2.imread(str(title_card_path))
    if png is None:
        raise FileNotFoundError(f"No se pudo cargar el logo en: {title_card_path}")
    crop = png[32:122, 64:218].copy()
    nh = target_height
    nw = int(round(crop.shape[1] * (nh / crop.shape[0])))
    crop_rs = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_AREA)
    alpha_rs = np.ones((nh, nw), dtype=np.float32)
    return crop_rs, alpha_rs


def put_nn_logo(canvas_bgr: np.ndarray, logo_bgr: np.ndarray, logo_alpha: np.ndarray, opacity: float = 1.0) -> None:
    """Superpone el logotipo NN en la esquina superior izquierda."""
    if opacity <= 0.01:
        return
    lh, lw = logo_bgr.shape[:2]
    x0, y0 = 88, 52
    roi = canvas_bgr[y0 : y0 + lh, x0 : x0 + lw].astype(np.float32)
    a = (logo_alpha * opacity)[..., None]
    canvas_bgr[y0 : y0 + lh, x0 : x0 + lw] = (roi * (1.0 - a) + logo_bgr.astype(np.float32) * a).astype(np.uint8)


def draw_badge(
    canvas_bgr: np.ndarray,
    masks: dict,
    icon_name: str,
    color_key: str,
    cx: float,
    cy: float,
    radius: float,
    appear_p: float = 1.0,
    opacity: float = 1.0,
    bg_fill_bgr: tuple = (255, 255, 255),
    highlight_pulse: float = 0.0,
) -> None:
    """
    Dibuja un icono circular monotrazo centrado en (cx, cy) con animación ease-out-back,
    trazado progresivo del anillo exterior y halo opcional de énfasis.
    """
    if appear_p <= 0.001 or opacity <= 0.001:
        return
    scale = ease_out_back(appear_p, s=1.25)
    if highlight_pulse > 0.0:
        scale *= 1.0 + 0.045 * math.sin(highlight_pulse * math.pi)
    r_cur = int(round(radius * scale))
    if r_cur < 6:
        return

    col_bgr = COLORS_BGR[color_key]
    stroke_px = max(3, int(round(STROKE * (r_cur / BADGE_R))))

    if highlight_pulse > 0.01:
        halo_r = int(round(r_cur * (1.0 + 0.12 * highlight_pulse)))
        halo_alpha = 0.22 * (1.0 - highlight_pulse) * opacity
        if halo_alpha > 0.01:
            overlay = canvas_bgr.copy()
            cv2.circle(overlay, (int(cx), int(cy)), halo_r, col_bgr, thickness=max(2, stroke_px // 2), lineType=cv2.LINE_AA)
            cv2.addWeighted(overlay, halo_alpha, canvas_bgr, 1.0 - halo_alpha, 0, dst=canvas_bgr)

    pad = stroke_px + 6
    x0, y0 = int(cx) - r_cur - pad, int(cy) - r_cur - pad
    x1, y1 = int(cx) + r_cur + pad, int(cy) + r_cur + pad
    if x1 <= 0 or y1 <= 0 or x0 >= W or y0 >= H:
        return

    pw, ph = x1 - x0, y1 - y0
    lcx, lcy = int(cx) - x0, int(cy) - y0

    cx0, cy0 = max(0, x0), max(0, y0)
    cx1, cy1 = min(W, x1), min(H, y1)
    lx0, ly0 = cx0 - x0, cy0 - y0
    lx1, ly1 = lx0 + (cx1 - cx0), ly0 + (cy1 - cy0)

    roi = canvas_bgr[cy0:cy1, cx0:cx1].astype(np.float32)

    fill_mask = np.zeros((ph, pw), dtype=np.uint8)
    cv2.circle(fill_mask, (lcx, lcy), r_cur, 255, -1, lineType=cv2.LINE_AA)
    fill_a = (fill_mask[ly0:ly1, lx0:lx1].astype(np.float32) / 255.0 * opacity)[..., None]
    bg_arr = np.array(bg_fill_bgr, dtype=np.float32)[None, None, :]
    roi = roi * (1.0 - fill_a) + bg_arr * fill_a

    ring_mask = np.zeros((ph, pw), dtype=np.uint8)
    arc_p = clamp(appear_p / 0.75, 0.0, 1.0)
    if arc_p >= 0.999:
        cv2.circle(ring_mask, (lcx, lcy), r_cur, 255, thickness=stroke_px, lineType=cv2.LINE_AA)
    else:
        end_deg = -90.0 + 360.0 * ease_out_cubic(arc_p)
        cv2.ellipse(ring_mask, (lcx, lcy), (r_cur, r_cur), 0, -90, end_deg, 255, thickness=stroke_px, lineType=cv2.LINE_AA)

    icon_scale = r_cur / float(BADGE_R)
    icon_sz = max(8, int(round(BADGE_SZ * icon_scale)))
    scaled_icon = cv2.resize(masks[icon_name], (icon_sz, icon_sz), interpolation=cv2.INTER_AREA)

    ix0 = lcx - icon_sz // 2
    iy0 = lcy - icon_sz // 2
    ix1, iy1 = ix0 + icon_sz, iy0 + icon_sz

    sx0, sy0 = max(0, ix0), max(0, iy0)
    sx1, sy1 = min(pw, ix1), min(ph, iy1)
    if sx1 > sx0 and sy1 > sy0:
        icon_fade = clamp((appear_p - 0.12) / 0.65, 0.0, 1.0)
        sub_icon = (scaled_icon[sy0 - iy0 : sy1 - iy0, sx0 - ix0 : sx1 - ix0].astype(np.float32) * icon_fade).astype(np.uint8)
        ring_mask[sy0:sy1, sx0:sx1] = np.maximum(ring_mask[sy0:sy1, sx0:sx1], sub_icon)

    stroke_a = (ring_mask[ly0:ly1, lx0:lx1].astype(np.float32) / 255.0 * opacity)[..., None]
    col_arr = np.array(col_bgr, dtype=np.float32)[None, None, :]
    roi = roi * (1.0 - stroke_a) + col_arr * stroke_a

    canvas_bgr[cy0:cy1, cx0:cx1] = roi.astype(np.uint8)


def draw_sound_waves(
    canvas_bgr: np.ndarray,
    x_from: float,
    y_from: float,
    x_to: float,
    y_to: float,
    color_key: str,
    t: float,
    num_arcs: int = 4,
    span_deg: float = 34,
    opacity: float = 1.0,
) -> None:
    """Dibuja arcos concéntricos de onda sonora viajando desde (x_from, y_from) hacia (x_to, y_to)."""
    if opacity <= 0.01:
        return
    dx = x_to - x_from
    dy = y_to - y_from
    dist = math.hypot(dx, dy)
    base_angle = math.degrees(math.atan2(dy, dx))
    col_bgr = COLORS_BGR[color_key]

    r_min = dist * 0.24
    r_max = dist * 0.74
    cycle = (t * 0.85) % 1.0

    for i in range(num_arcs):
        phase = (i + cycle) / float(num_arcs)
        r = int(round(r_min + (r_max - r_min) * phase))
        env = math.sin(phase * math.pi) ** 1.2
        alpha = env * opacity * 0.88
        if alpha <= 0.02:
            continue
        overlay = canvas_bgr.copy()
        cv2.ellipse(
            overlay,
            (int(x_from), int(y_from)),
            (r, int(round(r * 1.15))),
            0,
            base_angle - span_deg,
            base_angle + span_deg,
            col_bgr,
            thickness=5,
            lineType=cv2.LINE_AA,
        )
        cv2.addWeighted(overlay, alpha, canvas_bgr, 1.0 - alpha, 0, dst=canvas_bgr)


def draw_falling_digits(
    pil_draw: ImageDraw.ImageDraw,
    cx: float,
    y_top: float,
    y_bottom: float,
    t: float,
    opacity: float = 1.0,
) -> None:
    """Dibuja las 8 columnas verticales de dígitos verdes cayendo bajo el icono de IA."""
    if opacity <= 0.01 or y_bottom <= y_top + 10:
        return
    col_offsets = [-112, -80, -48, -16, 16, 48, 80, 112]
    col_speeds = [140, 190, 155, 210, 175, 145, 195, 160]
    digits_seq = "234567891023456789"
    base_rgb = COLORS_RGB["green"]

    step_y = 26
    for idx, dx in enumerate(col_offsets):
        x = int(cx + dx - 7)
        scroll = int(t * col_speeds[idx])
        num_rows = int((y_bottom - y_top) // step_y)
        for r in range(num_rows):
            yy = y_top + r * step_y + (scroll % step_y)
            if yy < y_top or yy > y_bottom - 18:
                continue
            edge_fade = min(clamp((yy - y_top) / 45.0), clamp((y_bottom - yy) / 55.0))
            a = opacity * edge_fade * 0.85
            if a <= 0.05:
                continue
            c_rgb = tuple(int(round(255 - (255 - c) * a)) for c in base_rgb)
            ch_idx = (r + idx * 3 + (scroll // step_y)) % len(digits_seq)
            pil_draw.text((x, int(yy)), digits_seq[ch_idx], font=FONTS["mono"], fill=c_rgb)


def draw_flow_arrow(
    canvas_bgr: np.ndarray,
    x0: float,
    x1: float,
    y: float,
    color_key: str,
    progress: float,
    opacity: float = 1.0,
) -> None:
    """Dibuja una flecha horizontal monotrazo animada de x0 a x1."""
    if progress <= 0.01 or opacity <= 0.01:
        return
    p = ease_out_cubic(clamp(progress))
    cur_x1 = int(round(x0 + (x1 - x0) * p))
    col_bgr = COLORS_BGR[color_key]
    overlay = canvas_bgr.copy()
    cv2.line(overlay, (int(x0), int(y)), (cur_x1, int(y)), col_bgr, thickness=6, lineType=cv2.LINE_AA)
    if p > 0.55:
        ah_p = clamp((p - 0.55) / 0.45)
        ah_len = int(round(18 * ah_p))
        if ah_len > 2:
            cv2.line(overlay, (cur_x1, int(y)), (cur_x1 - ah_len, int(y) - ah_len), col_bgr, thickness=6, lineType=cv2.LINE_AA)
            cv2.line(overlay, (cur_x1, int(y)), (cur_x1 - ah_len, int(y) + ah_len), col_bgr, thickness=6, lineType=cv2.LINE_AA)
    cv2.addWeighted(overlay, opacity, canvas_bgr, 1.0 - opacity, 0, dst=canvas_bgr)


def draw_centered_text(
    pil_draw: ImageDraw.ImageDraw,
    text: str,
    cx: float,
    cy: float,
    font_key: str,
    rgb_color: tuple,
    opacity: float = 1.0,
    bg_rgb: tuple = (255, 255, 255),
    line_gap: int = 14,
) -> None:
    """Renderiza texto centrado (uni o multilínea) con mezcla suave contra el fondo."""
    if opacity <= 0.01 or not text:
        return
    font = FONTS[font_key]
    col = tuple(int(round(bg_rgb[i] + (rgb_color[i] - bg_rgb[i]) * opacity)) for i in range(3))
    lines = text.split("\n")
    heights, widths = [], []
    for ln in lines:
        bbox = pil_draw.textbbox((0, 0), ln, font=font)
        widths.append(bbox[2] - bbox[0])
        heights.append(bbox[3] - bbox[1])
    total_h = sum(heights) + line_gap * (len(lines) - 1)
    cur_y = cy - total_h / 2.0
    for ln, w, h in zip(lines, widths, heights):
        pil_draw.text((int(round(cx - w / 2.0)), int(round(cur_y))), ln, font=font, fill=col)
        cur_y += h + line_gap


def add_subtitle_overlay(frame_bgr: np.ndarray, t: float, script_segments: list) -> np.ndarray:
    """Añade una barra inferior de subtítulos sincronizados según `script_segments`."""
    cur_text = ""
    for t0, t1, txt in script_segments:
        if t0 <= t <= t1:
            cur_text = txt
            break
    if not cur_text:
        return frame_bgr
    out = frame_bgr.copy()
    pil_img = Image.fromarray(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img, "RGBA")
    font = FONTS["sub"]
    bbox = draw.textbbox((0, 0), cur_text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    pad_x, pad_y = 28, 12
    rx0 = W // 2 - tw // 2 - pad_x
    ry0 = H - 64 - th // 2 - pad_y
    rx1 = W // 2 + tw // 2 + pad_x
    ry1 = H - 64 + th // 2 + pad_y
    draw.rounded_rectangle([rx0, ry0, rx1, ry1], radius=18, fill=(35, 40, 45, 215))
    draw.text((W // 2 - tw // 2, ry0 + pad_y - 2), cur_text, font=font, fill=(255, 255, 255, 255))
    return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)


def export_videos(
    output_stem: str,
    duration: float,
    render_fn: Callable[[float, dict, np.ndarray, np.ndarray], np.ndarray],
    masks: dict,
    logo_bgr: np.ndarray,
    logo_alpha: np.ndarray,
    script_segments: list | None = None,
    sample_times: list | None = None,
    preview_prefix: str = "preview",
    out_dir: Path = OUTPUT_DIR,
    previews_dir: Path = PREVIEWS_DIR,
    progress_callback: Callable[[int, int, float], None] | None = None,
) -> tuple[Path, Path | None]:
    """
    Renderiza `duration * FPS` fotogramas y exporta simultáneamente:
      - `<output_stem>.mp4` (versión limpia sin audio)
      - `<output_stem>_subtitulado.mp4` (si se pasa `script_segments`)
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    previews_dir.mkdir(parents=True, exist_ok=True)
    total_frames = int(round(duration * FPS))
    ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()

    clean_mp4 = out_dir / f"{output_stem}.mp4"
    cmd_base = [
        ffmpeg_exe, "-y", "-f", "rawvideo", "-vcodec", "rawvideo",
        "-s", f"{W}x{H}", "-pix_fmt", "bgr24", "-r", str(FPS),
        "-i", "-", "-an", "-vcodec", "libx264", "-pix_fmt", "yuv420p",
        "-preset", "fast", "-crf", "18",
    ]
    p_clean = subprocess.Popen(cmd_base + [str(clean_mp4)], stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)

    sub_mp4 = None
    p_sub = None
    if script_segments:
        sub_mp4 = out_dir / f"{output_stem}_subtitulado.mp4"
        p_sub = subprocess.Popen(cmd_base + [str(sub_mp4)], stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)

    sample_frames = {int(round(st * FPS)): st for st in (sample_times or [])}
    thumbs = []

    print(f"Renderizando {total_frames} fotogramas ({duration:.1f}s @ {FPS}fps, {W}x{H})...")
    for f_idx in range(total_frames):
        t = f_idx / float(FPS)
        frame = render_fn(t, masks, logo_bgr, logo_alpha)
        p_clean.stdin.write(frame.tobytes())

        frame_for_thumb = frame
        if p_sub is not None:
            frame_sub = add_subtitle_overlay(frame, t, script_segments)
            p_sub.stdin.write(frame_sub.tobytes())
            frame_for_thumb = frame_sub

        if f_idx in sample_frames:
            st = sample_frames[f_idx]
            cv2.imwrite(
                str(previews_dir / f"{preview_prefix}_{st:04.1f}s.jpg"),
                frame,
                [cv2.IMWRITE_JPEG_QUALITY, 92],
            )
            sm = cv2.resize(frame_for_thumb, (480, 270), interpolation=cv2.INTER_AREA)
            cv2.putText(sm, f"{st:.1f}s", (12, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 220), 2, cv2.LINE_AA)
            thumbs.append(sm)

        if progress_callback is not None and ((f_idx + 1) % 6 == 0 or (f_idx + 1) == total_frames):
            progress_callback(f_idx + 1, total_frames, t)

        if (f_idx + 1) % 120 == 0 or (f_idx + 1) == total_frames:
            print(f"  {f_idx + 1}/{total_frames} fotogramas ({t:.1f}s)...")

    p_clean.stdin.close()
    p_clean.wait()
    if p_sub is not None:
        p_sub.stdin.close()
        p_sub.wait()

    if thumbs:
        cols = 3
        while len(thumbs) % cols:
            thumbs.append(np.full_like(thumbs[0], 255))
        rows = [np.hstack(thumbs[i : i + cols]) for i in range(0, len(thumbs), cols)]
        grid_path = previews_dir / f"{preview_prefix}_grid.jpg"
        cv2.imwrite(str(grid_path), np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 90])

    print("Exportación completada:", clean_mp4)
    if sub_mp4:
        print("Exportación subtitulada:", sub_mp4)
    return clean_mp4, sub_mp4
