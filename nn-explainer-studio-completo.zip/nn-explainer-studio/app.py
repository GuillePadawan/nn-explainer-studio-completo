"""
Servidor web local (100 % librería estándar Python, sin FastAPI ni dependencias externas)
para la interfaz gráfica de NN Explainer Studio.

Ejecución:
    python app.py
Abre automáticamente http://127.0.0.1:8080 en el navegador.
"""

from __future__ import annotations

import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import sys
import threading
import time
import urllib.parse
import uuid
import webbrowser
from pathlib import Path
from typing import Any
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from nn_motion import (
    COLORS_RGB,
    OUTPUT_DIR,
    PREVIEWS_DIR,
    VALID_ICONS,
    draw_badge,
    load_all_masks,
    load_spec_file,
    prepare_nn_logo,
    render_single_preview_jpeg,
    render_video_from_spec,
    validate_spec,
)

WEB_DIR = ROOT / "web"
SPECS_DIR = ROOT / "videos" / "specs"
SPECS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
PREVIEWS_DIR.mkdir(parents=True, exist_ok=True)

print("Cargando máscaras vectoriales e identidad NN...")
MASKS = load_all_masks()
LOGO_BGR, LOGO_ALPHA = prepare_nn_logo()

ICON_METADATA = [
    {"id": "agent",         "label": "Agente (Headset)",       "default_color": "orange",   "desc": "Agente de atención o llamadas entrantes"},
    {"id": "customer",      "label": "Cliente (Persona)",      "default_color": "blue",     "desc": "Cliente o interlocutor"},
    {"id": "robot",         "label": "IA / Bot (Antena)",      "default_color": "green",    "desc": "Motor de Inteligencia Artificial"},
    {"id": "funnel",        "label": "Embudo (Filtro)",        "default_color": "lavender", "desc": "Síntesis, filtrado o estructuración"},
    {"id": "folder",        "label": "Carpeta (Archivos)",     "default_color": "red",      "desc": "Repositorio o expediente"},
    {"id": "waveform",      "label": "Onda de Voz",            "default_color": "orange",   "desc": "Audio de llamada o Proof of Concept"},
    {"id": "transcript",    "label": "Transcripción",          "default_color": "green",    "desc": "Documento de texto con burbuja de voz"},
    {"id": "reason",        "label": "Motivo (?)",             "default_color": "blue",     "desc": "Por qué nos contacta el cliente"},
    {"id": "intent",        "label": "Intención (Diana)",      "default_color": "orange",   "desc": "Objetivo o prioridad del cliente"},
    {"id": "issues",        "label": "Problemas (!)",          "default_color": "red",      "desc": "Incidencias o puntos de fricción"},
    {"id": "outcome",       "label": "Resultado (Check)",      "default_color": "green",    "desc": "Resolución o qué ocurre en la llamada"},
    {"id": "evidence",      "label": "Evidencia (Lupa)",       "default_color": "lavender", "desc": "Hallazgos verificados e insights"},
    {"id": "improvement",   "label": "Mejora / Acción",        "default_color": "red",      "desc": "Crecimiento, oportunidades o acción"},
    {"id": "understanding", "label": "Comprensión (Bombilla)", "default_color": "blue",     "desc": "Conocimiento profundo del cliente"},
    {"id": "provider",      "label": "Proveedor Externo",      "default_color": "orange",   "desc": "Centro de servicios o socio externo"},
    {"id": "visibility",    "label": "Visibilidad (Ojo)",      "default_color": "lavender", "desc": "Supervisión, transparencia o control"},
]

ICON_THUMBS_CACHE: dict[str, bytes] = {}


def _get_icon_thumb(icon_id: str, color_key: str | None = None) -> bytes:
    cache_key = f"{icon_id}:{color_key or 'default'}"
    if cache_key in ICON_THUMBS_CACHE:
        return ICON_THUMBS_CACHE[cache_key]
    meta = next((m for m in ICON_METADATA if m["id"] == icon_id), ICON_METADATA[0])
    col = color_key if (color_key in COLORS_RGB and color_key != "white") else meta["default_color"]
    sz = 180
    canvas = np.full((sz, sz, 3), 255, dtype=np.uint8)
    draw_badge(canvas, MASKS, meta["id"], col, sz // 2, sz // 2, 74, appear_p=1.0, opacity=1.0)
    ok, buf = cv2.imencode(".png", canvas)
    data = buf.tobytes() if ok else b""
    ICON_THUMBS_CACHE[cache_key] = data
    return data


JOBS_LOCK = threading.Lock()
JOBS: dict[str, dict[str, Any]] = {}


def _run_render_job(job_id: str, spec: dict[str, Any]) -> None:
    def _on_progress(frame_idx: int, total_frames: int, t_sec: float) -> None:
        with JOBS_LOCK:
            if job_id in JOBS:
                JOBS[job_id]["frame"] = frame_idx
                JOBS[job_id]["total_frames"] = total_frames
                JOBS[job_id]["current_time"] = round(t_sec, 1)
                JOBS[job_id]["percent"] = int(round((frame_idx / max(1, total_frames)) * 100))

    try:
        clean_mp4, sub_mp4 = render_video_from_spec(
            spec=spec,
            masks=MASKS,
            logo_bgr=LOGO_BGR,
            logo_alpha=LOGO_ALPHA,
            progress_callback=_on_progress,
        )
        stem = clean_mp4.stem
        grid_file = PREVIEWS_DIR / f"preview_{stem}_grid.jpg"
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "done"
            JOBS[job_id]["percent"] = 100
            JOBS[job_id]["clean_url"] = f"/output/{clean_mp4.name}?t={int(time.time())}"
            JOBS[job_id]["sub_url"] = f"/output/{sub_mp4.name}?t={int(time.time())}" if sub_mp4 else None
            JOBS[job_id]["grid_url"] = f"/output/previews/{grid_file.name}?t={int(time.time())}" if grid_file.exists() else None
    except Exception as exc:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = str(exc)


class StudioRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        # Silenciar logs repetitivos de polling de estado
        if "/api/status/" in self.path or "/api/icon-thumb/" in self.path:
            return
        super().log_message(format, *args)

    def _send_json(self, payload: Any, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _send_bytes(self, data: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_file(self, file_path: Path) -> None:
        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "Archivo no encontrado")
            return
        ctype, _ = mimetypes.guess_type(str(file_path))
        ctype = ctype or "application/octet-stream"
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Accept-Ranges", "bytes")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path in ("/", "/index.html"):
            self._serve_file(WEB_DIR / "index.html")
            return

        if path == "/api/catalog":
            examples = {}
            for p in sorted(SPECS_DIR.glob("*.json")):
                try:
                    examples[p.stem] = load_spec_file(p)
                except Exception:
                    pass
            existing_videos = [
                {"name": p.name, "url": f"/output/{p.name}", "size_kb": round(p.stat().st_size / 1024, 1)}
                for p in sorted(OUTPUT_DIR.glob("*.mp4"))
            ]
            self._send_json({
                "icons": ICON_METADATA,
                "colors": {k: f"#{v[0]:02X}{v[1]:02X}{v[2]:02X}" for k, v in COLORS_RGB.items()},
                "examples": examples,
                "existing_videos": existing_videos,
            })
            return

        if path.startswith("/api/icon-thumb/"):
            icon_id = path.split("/api/icon-thumb/", 1)[1].strip("/")
            qs = urllib.parse.parse_qs(parsed.query)
            color_k = qs.get("color", [None])[0]
            if icon_id not in VALID_ICONS:
                self.send_error(404, "Icono desconocido")
                return
            png_bytes = _get_icon_thumb(icon_id, color_k)
            self._send_bytes(png_bytes, "image/png")
            return

        if path.startswith("/api/status/"):
            job_id = path.split("/api/status/", 1)[1].strip("/")
            with JOBS_LOCK:
                job = JOBS.get(job_id)
            if not job:
                self._send_json({"error": "Trabajo no encontrado"}, status=404)
                return
            self._send_json(job)
            return

        if path.startswith("/output/previews/"):
            fname = Path(path.split("/output/previews/", 1)[1]).name
            self._serve_file(PREVIEWS_DIR / fname)
            return

        if path.startswith("/output/"):
            fname = Path(path.split("/output/", 1)[1]).name
            self._serve_file(OUTPUT_DIR / fname)
            return

        self.send_error(404, "Ruta no encontrada")

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length) if length > 0 else b"{}"
        try:
            body = json.loads(raw_body.decode("utf-8"))
        except Exception as exc:
            self._send_json({"error": f"JSON inválido: {exc}"}, status=400)
            return

        if path == "/api/preview-frame":
            spec = body.get("spec") or {}
            t_sec = float(body.get("t", 1.5))
            subtitles = bool(body.get("subtitles", True))
            errors = validate_spec(spec)
            if errors:
                self._send_json({"error": "; ".join(errors)}, status=400)
                return
            try:
                jpg_bytes = render_single_preview_jpeg(spec, t_sec, MASKS, LOGO_BGR, LOGO_ALPHA, include_subtitles=subtitles)
                b64 = base64.b64encode(jpg_bytes).decode("ascii")
                self._send_json({"image_data_url": f"data:image/jpeg;base64,{b64}", "t": t_sec})
            except Exception as exc:
                self._send_json({"error": str(exc)}, status=500)
            return

        if path == "/api/render":
            spec = body.get("spec") or {}
            errors = validate_spec(spec)
            if errors:
                self._send_json({"error": "; ".join(errors)}, status=400)
                return

            stem = str(spec.get("output_stem", "video_nn_custom")).strip() or "video_nn_custom"
            safe_stem = "".join(c if (c.isalnum() or c in ("_", "-")) else "_" for c in stem)
            spec["output_stem"] = safe_stem
            spec_path = SPECS_DIR / f"{safe_stem}.json"
            spec_path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")

            job_id = uuid.uuid4().hex[:10]
            total_frames = int(round(float(spec.get("duration", 16.0)) * 30))
            with JOBS_LOCK:
                JOBS[job_id] = {
                    "job_id": job_id,
                    "output_stem": safe_stem,
                    "status": "running",
                    "frame": 0,
                    "total_frames": total_frames,
                    "current_time": 0.0,
                    "percent": 0,
                    "clean_url": None,
                    "sub_url": None,
                    "grid_url": None,
                    "error": None,
                }
            t_worker = threading.Thread(target=_run_render_job, args=(job_id, spec), daemon=True)
            t_worker.start()
            self._send_json({"job_id": job_id, "saved_spec": str(spec_path.relative_to(ROOT))})
            return

        self.send_error(404, "Endpoint POST no encontrado")


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Inicia la interfaz web local de NN Explainer Studio.")
    parser.add_argument("--port", type=int, default=8080, help="Puerto local (por defecto 8080)")
    parser.add_argument("--no-browser", action="store_true", help="No abrir el navegador automáticamente")
    args = parser.parse_args()

    url = f"http://127.0.0.1:{args.port}"
    server = ThreadingHTTPServer(("127.0.0.1", args.port), StudioRequestHandler)
    print(f"\n============================================================")
    print(f"  NN Explainer Studio activo en: {url}")
    print(f"  (Sin conexión a internet ni API keys requeridas)")
    print(f"  Pulsa Ctrl+C para detener el servidor.")
    print(f"============================================================\n")

    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando servidor local...")
        server.server_close()


if __name__ == "__main__":
    main()
