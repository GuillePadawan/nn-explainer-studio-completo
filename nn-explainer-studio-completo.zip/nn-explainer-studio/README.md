# NN Explainer Video Studio

Proyecto modular en Python con **interfaz web interactiva (`app.py` + `web/index.html`)** y **motor declarativo JSON (`schema_renderer.py`)** para producir vídeos explicativos corporativos en **Full HD (`1920×1080`, 30 fps, sin audio)** con el estilo visual NN × Genesys.

Funciona **100 % en local sin necesidad de API keys, cuentas de Google ni FastAPI** (usa exclusivamente `http.server` de la librería estándar de Python) e incluye un asistente de **Prompt para el Copilot de empresa**.

---

## Estructura del proyecto

```text
nn-explainer-studio/
├── README.md
├── iniciar_estudio.bat                  # Lanzador con doble clic en Windows
├── app.py                               # Servidor web local (http.server nativo, sin FastAPI)
├── web/
│   └── index.html                       # Interfaz gráfica: Prompt Copilot + Editor Visual + Render MP4
├── pyproject.toml
├── requirements.txt
├── .gitignore
├── assets/
│   ├── logos/
│   │   └── nn_title_card.png            # Cartela original de donde se recorta el logo NN
│   ├── masks/                           # 16 máscaras PNG de 800×800 px listas para animar
│   └── reference/
│       ├── original_video.mp4           # Vídeo original de referencia
│       ├── badge_showcase.jpg           # Catálogo visual con los 16 iconos
│       └── ref_01_titulo.jpg .. ref_06_speech.jpg
├── docs/
│   ├── guia_estilo_y_prompts.md         # ADN visual + prompts maestros para IA (imagen/vídeo)
│   ├── storyboard_video_36s.md          # Escaleta y capturas del vídeo de 36 s
│   └── storyboard_video_16s.md          # Escaleta y capturas del vídeo de 16 s
├── src/nn_motion/
│   ├── config.py                        # Paleta, dimensiones, rutas y fuentes tipográficas
│   ├── badges.py                        # Cargador y generador de iconos monotrazo (800×800)
│   ├── engine.py                        # Primitivas de animación, subtítulos y exportador ffmpeg
│   └── schema_renderer.py               # Motor declarativo: convierte archivos JSON en vídeos MP4
├── scripts/
│   ├── render_json.py                   # Renderiza cualquier archivo .json desde línea de comandos
│   ├── generate_assets.py               # Regenera assets/masks/*.png y badge_showcase.jpg
│   └── analyze_video.py                 # Extrae fotogramas clave, hojas de contacto y paleta
├── videos/
│   ├── specs/
│   │   ├── video_01_genai_36s.json      # Especificación JSON completa del vídeo de 36 s
│   │   └── video_02_insights_16s.json   # Especificación JSON completa del vídeo de 16 s
│   ├── video_01_genai_36s.py            # Script Python original del vídeo de 36 s
│   ├── video_02_insights_16s.py         # Script Python original del vídeo de 16 s
│   └── template_nuevo_video.py          # Plantilla Python manual
└── output/
    ├── previews/                        # Capturas clave y rejillas de verificación
    ├── video_nn_genai_36s.mp4
    ├── video_nn_genai_36s_subtitulado.mp4
    ├── video_nn_insights_16s.mp4
    └── video_nn_insights_16s_subtitulado.mp4
```

---

## Opción 1: Usar la Interfaz Gráfica Web + Copilot de Empresa (Recomendado)

1. Haz doble clic en `iniciar_estudio.bat` o ejecuta en la consola:
   ```powershell
   .\.venv\Scripts\python.exe app.py
   ```
2. Se abrirá automáticamente `http://127.0.0.1:8080` en tu navegador.
3. En la pestaña **1. Asistente Copilot de Empresa**:
   - Escribe el nombre del archivo, la duración en segundos y pega tu guion.
   - Pulsa **📋 Generar y Copiar Prompt para Copilot** (el prompt ya incluye automáticamente las reglas, el catálogo de 16 iconos y los 2 ejemplos completos de 36 s y 16 s).
   - Pégalo en el **Microsoft Copilot de tu empresa**.
   - Pega la respuesta JSON de Copilot en el **Paso B** y pulsa **✨ Importar JSON al Editor Visual**.
4. En la pestaña **2. Editor Visual de Escenas y Frases**:
   - Revisa o ajusta visualmente cualquier frase, segundo, icono o color.
   - Mueve el deslizador de la derecha para **previsualizar al instante cualquier fotograma** en `1920×1080`.
5. Pulsa **🎬 Generar Vídeo MP4** para producir y descargar tanto la versión limpia como la versión subtitulada.

---

## Opción 2: Renderizar un archivo JSON directamente por consola

Si ya tienes el JSON generado por Copilot guardado en un archivo (por ejemplo `mi_video.json`), puedes renderizarlo directamente sin abrir la interfaz web:

```powershell
.\.venv\Scripts\python.exe scripts\render_json.py videos\specs\video_01_genai_36s.json
.\.venv\Scripts\python.exe scripts\render_json.py videos\specs\video_02_insights_16s.json
```

---

## Catálogo de iconos y colores disponibles

Catálogo visual completo: [badge_showcase.jpg](assets/reference/badge_showcase.jpg)

| Icono | Origen | Concepto recomendado | Color por defecto (`COLORS_RGB`) |
|---|---|---|---|
| `agent` | Original | Agente / Llamada / Conversación | `orange` (`#DD5B13`) |
| `customer` | Original | Cliente / Usuario | `blue` (`#7DA9D3`) |
| `robot` | Original | Inteligencia Artificial / GenAI | `green` (`#98BC3D`) |
| `funnel` | Original | Filtrado / Clasificación / Análisis | `lavender` (`#9B8AC4`) |
| `folder` | Original | Carpetas / Almacenamiento | `red` (`#D43316`) |
| `waveform` | Original | Cartela de concepto / Voz | `white` sobre fondo `orange` |
| `transcript` | Custom | Transcripción / Documento | `green` (`#98BC3D`) |
| `reason` | Custom | Motivo de contacto (`?`) | `blue` (`#7DA9D3`) |
| `intent` | Custom | Intención / Objetivo (diana) | `orange` (`#DD5B13`) |
| `issues` | Custom | Problemas / Incidencias (alerta) | `red` (`#D43316`) |
| `outcome` | Custom | Resultado / Resolución (escudo) | `green` (`#98BC3D`) |
| `evidence` | Custom | Evidencia / Insights (lupa) | `lavender` (`#9B8AC4`) |
| `improvement` | Custom | Oportunidades / Acción (gráfica) | `red` (`#D43316`) |
| `understanding` | Custom | Comprensión / Empatía (corazón) | `blue` (`#7DA9D3`) |
| `provider` | Custom | Proveedor de servicios externo | `orange` (`#DD5B13`) |
| `visibility` | Custom | Mayor visibilidad (ojo) | `lavender` (`#9B8AC4`) |
